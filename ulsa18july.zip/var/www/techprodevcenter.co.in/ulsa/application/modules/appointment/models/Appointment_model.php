<?php    
class Appointment_model extends CI_Model
{
    public function __construct()
    {

        // Set orderable column fields
        $this->table = 'sc_appointment';
        $this->column_order = array( null,'name','sc_users.lastname','sc_users.email','sc_users.phone','sc_appointment_type.type', 'sc_desired_clinic.desired_clinic','appointment_date','appointment_state');
        // Set searchable column fields
        $this->column_search = array( 'sc_users.name','sc_users.lastname','sc_family_member.Firstname','sc_family_member.Lastname','sc_appointment_type.type','appointment_state','sc_desired_clinic.desired_clinic','appointment_date','appointment_state','sc_users.phone');
        // Set default order
        $this->order = array('sc_appointment.appointment_date' => 'asc');
    }
 
    public function getRows_appointment($postData){
        $this->_get_datatables_query_appointment($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $query = $this->db->get();
        return $query->result();
        // print_r($this->db->last_query()); die;
    }
    
    
    public function countAll_appointment(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered_appointment($postData){
        $this->_get_datatables_query_appointment($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    
    private function _get_datatables_query_appointment($postData){
        $this->db->where('approved_status', $_POST['id']);
        $this->db->where('sc_appointment.status', 1);
        $this->db->where('sc_users.status', 1);
        $this->db->where('sc_desired_clinic.status', 1);
        $this->db->select('sc_appointment.*,sc_users.name,sc_users.lastname,sc_users.phone,sc_users.email,sc_desired_clinic.desired_clinic,sc_appointment_type.type,sc_family_member.Firstname,sc_family_member.Lastname');
        $this->db->from($this->table);

        $this->db->join('sc_users', 'sc_appointment.user_id = sc_users.id', 'left'); 
        $this->db->join('sc_desired_clinic', 'sc_appointment.clinic_id = sc_desired_clinic.id', 'left'); 
        $this->db->join('sc_appointment_type', 'sc_appointment.appointment_type = sc_appointment_type.id', 'left'); 
        $this->db->join('sc_family_member', 'sc_appointment.family_member_id = sc_family_member.member_uniqid', 'left'); 




        if ($_SESSION['usertype'] == 2) {
            $this->db->where('sc_users.desired_clinic', $_SESSION['clinic']);
        } 
        
      
 
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

        
    public function appointmentDetails($id){

        $this->db->select('sc_appointment.*,sc_appointment_type.type,sc_users.name,sc_users.lastname,sc_users.phone,sc_users.email,sc_family_member.Firstname,
        sc_family_member.Lastname,sc_doctor.FName as docname,sc_desired_clinic.id as clinic_id');
        $this->db->from('sc_appointment');
        $this->db->join('sc_desired_clinic', 'sc_appointment.clinic_id = sc_desired_clinic.id','left'); 
        $this->db->join('sc_appointment_type', 'sc_appointment.appointment_type = sc_appointment_type.id','left'); 
        $this->db->join('sc_users', 'sc_appointment.user_id = sc_users.id', 'left'); 
        $this->db->join('sc_family_member', 'sc_appointment.family_member_id = sc_family_member.member_uniqid', 'left'); 
        $this->db->join('sc_doctor', 'sc_appointment.doctor_id = sc_doctor.id', 'left'); 



        $this->db->where('sc_appointment.id',$id);
        $data=$this->db->get()->result();
        return $data;
 
    }
    public function appointmentTime($id){   
        $this->db->select('sc_appointment.*,sc_appointment_time.*');
        $this->db->from('sc_appointment');
        $this->db->join('sc_appointment_time', 'sc_appointment.id =sc_appointment_time.appointment_id','left');
        $this->db->where('sc_appointment.id',$id);
        $data=$this->db->get()->result();
        return $data;
    }

    public function appointmenNote($id)
    {
        $this->db->select('sc_appointment.*,sc_notes.appointment_id,sc_notes.note_name,sc_notes.note_description');
        $this->db->from('sc_appointment');
        $this->db->join('sc_notes', 'sc_appointment.id = sc_notes.appointment_id','left'); 
        $this->db->where('sc_appointment.id',$id);
        $data=$this->db->get()->result();
        return $data;


    }

    public function approve($data,$id)
    {
        $this->db->where('id',$id);
       $q= $this->db->update('sc_appointment',$data);
    //    if($q==true){
    //        echo true;
    //    }else{
    //        echo false;
    //    }

    }
    public function cancelAppointment($data,$id)
    {
        $this->db->where('id',$id);
       $q= $this->db->update('sc_appointment',$data);
       if($q==true){
           echo true;
       }else{
           echo false;
       }

    }
    

    public function deleteAppointment($id,$status)
    {
        $this->db->where('id',$id);
        $q=$this->db->update('sc_appointment',$status);
        if($q==true){
            echo true;
        }else{
            echo false;
        }
    }

    public function getNotificationAppt(){
        $datetime = date("Y-m-d H:i:s");
        $timestamp = strtotime($datetime);
        $time = $timestamp - (3 * 60 *60);
        $datetime = date("Y-m-d H:i:s", $time);
        if ($_SESSION['usertype'] == 2) {
            $this->db->where('sc_appointment.clinic_id', $_SESSION['clinic']);
        }
        
        $this->db->select('sc_appointment.appointment_date,sc_appointment.reminder_date,sc_desired_clinic.desired_clinic AS clinicname,sc_users.name,sc_users.lastname,
        sc_users.email,sc_appointment_type.type');
        $this->db->from('sc_appointment');
        $this->db->join('sc_desired_clinic', 'sc_appointment.clinic_id = sc_desired_clinic.id'); 
        $this->db->join('sc_users', 'sc_appointment.user_id = sc_users.id');
        $this->db->join('sc_appointment_type','sc_appointment.appointment_type = sc_appointment_type.id');
        $this->db->where('sc_appointment.appointment_date > "'.$datetime.'"');
        $this->db->where('sc_appointment.status',1);
        $this->db->order_by("sc_appointment.appointment_date", "desc");
        $this->db->limit(10); 
        return $this->db->get()->result();
        // print_r($this->db->last_query()); die;

    }

    public function getNewMessages(){
        $datetime = date("Y-m-d H:i:s");
        $timestamp = strtotime($datetime);
        $time = $timestamp - (3 * 60 *60);
        $datetime = date("Y-m-d H:i:s", $time);
        // if ($_SESSION['usertype'] == 2) {
        //     $this->db->where('appointment.clinic_id', $_SESSION['clinic']);
        // }
        
        $this->db->select('sc_desired_clinic.desired_clinic AS clinicname,sc_users.name,sc_users.lastname,
        sc_users.email,sc_message_table.created_date,MAX(sc_message_table.message) AS sc_usermsg,sc_message_table.from_user_id');
        $this->db->from('sc_users');
        $this->db->join('sc_desired_clinic', 'sc_users.desired_clinic = sc_desired_clinic.id'); 
        $this->db->join('sc_message_table', 'sc_users.id = sc_message_table.from_user_id'); 
        // $this->db->join('users', 'appointment.user_id = users.id');
        // $this->db->join('appointment_type','appointment.appointment_type = appointment_type.id');
        $this->db->where('sc_message_table.created_date > "'.$datetime.'"');
        // $this->db->where('appointment.status',1);
        $this->db->order_by("sc_message_table.created_date", "desc");
        $this->db->group_by("sc_message_table.from_user_id");
        $this->db->limit(10); 
        return $this->db->get()->result();
        // print_r($this->db->last_query()); die;

    }
    public function getDoctor($id)
    {

            $this->db->select('sc_appointment.*,sc_doctor_working.clinic_id,sc_doctor.id as doctorid,sc_doctor.FName as dcotorname');
            $this->db->from('sc_appointment');
            $this->db->join('sc_doctor_working', 'sc_appointment.clinic_id = sc_doctor_working.clinic_id','left'); 
            $this->db->join('sc_doctor', 'sc_doctor_working.doctor_id = sc_doctor.id','left'); 
            $this->db->where('sc_appointment.id',$id);
            $data=$this->db->get()->result();
            return $data;

    }

    public function events($id,$date)
    {
        $this->db->where('status',1);
        $this->db->where('doctor_id',$id);
        $this->db->where('start_event',$date);
        $q=$this->db->get('sc_doctor_appointment')->result();
        return $q;



    }


  


   
   
  
}
