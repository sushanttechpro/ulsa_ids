<?php   
date_default_timezone_set('Asia/Kolkata');

class Doctors extends CI_Controller
{
    public function __construct()
    {
        parent:: __construct();
        $this->load->model('Doctors_model');
        $this->load->helper('url');
        $this->load->library('session');
        
    }

    public function index()
    {
        
        $data['clinic']=$this->Doctors_model->getClinic();
        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header',$data);
        $this->load->view('index',$data);
        $this->load->view('footer',$data);
        
    }

    public function fetchDoctors()
    {
        $data = $row = array();
        $rows = $this->Doctors_model->getRows_doctor($_POST);
        // print_r($rows); die;
        foreach ($rows as $users) {
            $data[] = array(  '<img src="'.$users->image.' "  style="width:50px;height:50px;vertical-align:middle;border-radius:50%; "> ', 
           $users->name,$users->phone,$users->doctor_description,$users->desired_clinic,

                    $users->status == "0" ? '<label class="switch">
            <input type="checkbox" id="doctorstatus" data-user_toggle="' . $users->id . '"  >
            <span class="slider round"></span>
          </label>' : '<label class="switch">
          <input type="checkbox" id="doctorstatus" data-user_toggle="' . $users->id . '" checked >
          <span class="slider round"></span>
        </label>',
        '<i name="update" id="'.$users->id.'" class="fa fa-pencil makepoint edit_doctor" aria-hidden="true"></i> ',
        // <i name="delete" id="'.$users->id.'" class="fa fa-trash-o delete_doctor makepoint" style="margin-left: 20px;" aria-hidden="true"></i>

  
         );
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Doctors_model->countAll_doctor($_POST),
            "recordsFiltered" => $this->Doctors_model->countFiltered_doctor($_POST),
            "data" => $data,
        );
        echo json_encode($output);
    }

   

    public function addDoctor()
    {  
        
        $config['upload_path'] = './assets/images/doctor/';  
        $config['allowed_types'] = 'jpg|jpeg|png|gif';  
        $this->load->library('upload', $config);  
        if(!$this->upload->do_upload('image'))  
        {  
            echo $this->upload->display_errors();  
        }  
        else  
        {  
            $data = $this->upload->data();  

            $picture = array(
            'image'=>'assets/images/doctor/'.$data['file_name'],'name'=>$_POST['name'],'phone'=>$_POST['phone'],
            'doctor_description'=>$_POST['Ck_editor_value'] ,  'clinic_id'=>$_POST['clinic_id'],      
                );
        $this->Doctors_model->addDoctor($picture);
        } 
    }

    public function editDoctor()
    {
       
        $output = array();  
        $data = $this->Doctors_model->editDoctor($_POST["id"]);  
        foreach($data as $row)  
        {
             $output['id']=$row->id;
            //  $output['image'] = $row->image;  
             $output['name'] = $row->name; 
             $output['phone'] = $row->phone; 

             $output['clinic_id'] = $row->clinic_id;  

             $output['doctor_description'] = $row->doctor_description;  

        }  
        echo json_encode($output);

    }

    public function updateDoctor()
    {
       
         if(($_FILES['image']['name']!=="")){ 
            $id=$_POST['id'];
        

            $this->db->where('id',$id);
            $q= $this->db->get('doctor')->result()[0];
            $p=$q->{'image'};

            unlink(FCPATH.'/'.$p);

            $config['upload_path'] = './assets/images/doctor/';  
            $config['allowed_types'] = 'jpg|jpeg|png|gif';  
            $this->load->library('upload', $config);  
            $this->upload->do_upload('image') ; 
            $data = $this->upload->data();  

            $picture = array(
            'image'=>'assets/images/doctor/'.$_FILES['image']['name'],'name'=>$_POST['name'],'phone'=>$_POST['phone'],
            'clinic_id'=>$_POST['clinic_id'],
            'doctor_description'=>$_POST['Ck_editor_value'], 'updated_date'=>date("Y-m-d H:i:s")         
            );
            $this->db->where('id',$id);
            $this->db->update('doctor',$picture);
           
            }
             else{
                $id=$_POST['id'];
                 $this->db->where('id',$id);
                $image_exist= $this->db->get('doctor')->result()[0]->image;
                $data = array(
                    
                    'clinic_id'=>$_POST['clinic_id'],'name'=>$_POST['name'],'image'=>$image_exist,'phone'=>$_POST['phone'],
                    'doctor_description'=>$_POST['Ck_editor_value'],'updated_date'=>date("Y-m-d H:i:s")        
                        );
                        $this->db->where('id',$id);
                        $this->db->update('doctor',$data);
                    }
        echo true ;
            
    }
        
    
    public function deleteDoctor()
    {
        $id = $_POST['id'];
        $status=array('status'=>0,'deleted_date'=>date("Y-m-d H:i:s"));
        $this->Doctors_model->deleteDoctor($id,$status);

        // $id=$_POST['id'];
        // $this->Doctors_model->deleteDoctor($id);
        // echo true;

    }

    public function  change_dctor_status()
    {
        if ($_POST['prop'] == "false") {
            $this->db->where('id', $_POST['id']);
            $this->db->update('doctor', array('status' => 0));
        } else {
            $this->db->where('id', $_POST['id']);
            $this->db->update('doctor', array('status' => 1));
        }
    }

    


   
     
  


}






?>