<?php    
class Clinic_model extends CI_Model
{
    public function __construct()
    {

        // Set orderable column fields
        $this->table = 'desired_clinic';
        $this->column_order = array( 'image','desired_clinic','clinic_email','clinic_phoneno','working_hours','clinic_address');
        // Set searchable column fields
        $this->column_search = array( 'desired_clinic','clinic_email','clinic_phoneno','working_hours','clinic_address');
        // Set default order
        $this->order = array('id' => 'asc');
    }
 
    public function getRows_clinic($postData){
        $this->_get_datatables_query_clinic($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $query = $this->db->get();
        return $query->result();
    }
    
    
    public function countAll_clinic(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered_clinic($postData){
        $this->_get_datatables_query_clinic($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    
    private function _get_datatables_query_clinic($postData){
         
        $this->db->from($this->table);
        $this->db->where('status',1);

        if ($_SESSION['usertype'] == 2) {
            $this->db->where('id', $_SESSION['clinic']);
        }
 
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function editClinic($id){
        $this->db->where('id',$id);
        $q=$this->db->get('desired_clinic');
        return $q->result();
    }
   
    public function updateClinic($picture,$id){
        $this->db->where('id',$id);
        $output = $this->db->update('desired_clinic',$picture);
        return $output;
    }
    // public function deleteClinic($id){
    // // public function delete_braces_data($id){
    //     // $this->db->where('id',$id);
    //     // $q=  $this->db->get('desired_clinic')->result()[0];
    //     // $p=$q->{'image'};
    //     // unlink(FCPATH.'/'.$p);


    //     // $this->db->where('id',$id);
    //     // $this->db->delete('desired_clinic');
    // }

    public function deleteClinic($id,$status)
    {
        $this->db->where('id',$id);
       $q= $this->db->update('desired_clinic',$status);
       if ($q==true){
        echo true;
        }
      else{
        echo false;
        }
    }

    public function addClinic($picture){
       $q= $this->db->insert('desired_clinic',$picture);
        if ($q==true){
            echo true;
            }
          else{
            echo false;
            }
        
    }


    public function getRows_appoinmenttype($postData)
    {
        $this->_get_datatables_query_appoinmenttype($postData);
        if ($postData['length'] != -1) {
        $this->db->limit($postData['length'], $postData['start']);
         }
         $id=$_POST['id'];
         $this->db->where('clinic_id',$id);
        $query = $this->db->get('appointment_type')->result();
        return $query;

    }
    
    public function countAll_appoinmenttype($postData)
    {
        $this->db->from('appointment_type');
        return $this->db->count_all_results();
        
    }

    public function countFiltered_appoinmenttype($postData)
    {
        $this->_get_datatables_query_appoinmenttype($postData);
        $query = $this->db->get('appointment_type');
        return $query->num_rows();
        
    }
    
    public function _get_datatables_query_appoinmenttype($postData)
    {
        // Set searchable column fields
        $search= $this->column_search = array('type');
        // Set orderable column fields
        $colorder= $this->column_order = array( 'type');
        // Set default order
       
        $rorder= $this->order = array('id' => 'asc');

        $id=$_POST['id'];
        $this->db->get('appointment_type');
        $this->db->where('clinic_id',$id);
        $this->db->where('status',1);


        $i = 0;
        // loop searchable columns 
        foreach($search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }

        if(isset($postData['order'])){
            $this->db->order_by($colorder[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($rorder)){
            $order = $rorder;
            $this->db->order_by(key($order), $order[key($order)]);
        }

      
    }

    public function insertAppointmenttype($data)
    {
       $q= $this->db->insert('appointment_type',$data);
       if ($q==true){
        echo true;
        }
      else{
        echo false;
        }
    }

    public function editAppointmenttype($id)
    {
        $this->db->where('id',$id);
        $q=$this->db->get('appointment_type');
        return $q->result();

    }

    public function updateAppointmenttype($data,$id)
    {
        $this->db->where('id',$id);
       $q= $this->db->update('appointment_type',$data);
       if ($q==true){
        echo true;
        }
      else{
        echo false;
        }
    }

    public function deleteAppointmenttype($id,$status)
    {
        $this->db->where('id',$id);
       $q= $this->db->update('appointment_type',$status);
       if ($q==true){
        echo true;
        }
      else{
        echo false;
        }


    }



   
   
  
}
