<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <!-- <h2>Payments</h2> -->
            <!-- <small class="text-muted">Welcome to Swift application</small> -->
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                        <div style="padding-bottom: 0px !important;" class="header">
                        <h2 style="width:50%; float:left;">Appointment Type</h2>
                        <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addModal">Add Braces-Post OP</button> -->
                        <i data-toggle="modal" data-target="#addModal" style="float:right;font-size:xx-large; color:#007bff;" class="fa fa-plus-circle makepoint" aria-hidden="true"></i>

                        <!-- <button type="button" class="btn btn-default waves-effect m-r-20" data-toggle="modal" data-target="#defaultModal">Add Member</button> -->

                       
                    </div>
                    <div class="body table-responsive">
                        <table class="table table-bordered table-striped table-hover js-basic-example dataTable" data-id="<?=$id?>" id="appointment_type">
                            <thead>
                                <tr>
                                   
                                    <th>Appointment Type</th>
                                    <th>Action</th>
                                   
                                </tr>
                            </thead>
                        
                       
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



    
</section>
<div class="color-bg"></div>




<div class="modal fade" id="addModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
            <form id="add_aptype"  method="post">

        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Add Appointment Type</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>  

            </div>

            <div class="modal-body">
            <div class="form-group">
                    <div class="form-line">
                        <input type="hidden" name="id" id="id" value="<?php  echo $id?>">
                        <label>Appointment Type</label>
                        <input type="text" name="type" id="type" required class="form-control" maxlength="100" >
                    </div>
                </div>
                <div class="form-group">
                <div class="form-line">
                    <label>Note 1</label>
                    <input type="text" name="note_1" id="note_1" required class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description1</label>
                    <textarea id="note_description_1" name="note_description_1" rows="4" cols="50" required class="form-control"></textarea>

                    </div>
                </div>

                <div class="form-group">
                <div class="form-line">
                    <label>Note 2</label>
                    <input type="text" name="note_2" id="note_2"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description2</label>
                    <textarea id="note_description_2" name="note_description_2" rows="4" cols="50" class="form-control"></textarea>

                    </div>
                </div>
                <div class="form-group">
                <div class="form-line">
                    <label>Note 3</label>
                    <input type="text" name="note_3" id="note_3"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description3</label>
                    <textarea id="note_description_3" name="note_description_3" rows="4" cols="50"  class="form-control"></textarea>

                    </div>
                </div>

                <div class="form-group">
                <div class="form-line">
                    <label>Note 4</label>
                    <input type="text" name="note_4" id="note_4"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description4</label>
                    <textarea id="note_description_4" name="note_description_4" rows="4" cols="50"  class="form-control"></textarea>

                    </div>
                </div>

                <div class="form-group">
                <div class="form-line">
                    <label>Note 5</label>
                    <input type="text" name="note_5" id="note_5"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description5</label>
                    <textarea id="note_description_5" name="note_description_5" rows="4" cols="50"  class="form-control"></textarea>

                    </div>
                </div>

              
                <!-- <div class="form-group"> -->
                <div class="modal-footer">  
                    <input type="submit" value="Add" class=" btn btn-raised g-bg-cyan">
                    <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                </div>
            </form>
            </div>

        </div>
    </div>
</div>





<div class="modal fade" id="editModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
            <form id="edit_aptype"  method="post">

        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Update Appointment Type</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>  

            </div>

            <div class="modal-body">
            <div class="form-group">
                    <div class="form-line">
                        <input type="hidden" name="id" id="aid">
                        <label>Appointment Type</label>
                        <input type="text" name="type" id="atype" required class="form-control" maxlength="100" >
                    </div>
                </div>
                <div class="form-group">
                <div class="form-line">
                    <label>Note 1</label>
                    <input type="text" name="note_1" id="anote_1" required class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description1</label>
                    <textarea id="anote_description_1" name="note_description_1" rows="4" cols="50" required class="form-control"></textarea>

                    </div>
                </div>

                <div class="form-group">
                <div class="form-line">
                    <label>Note 2</label>
                    <input type="text" name="note_2" id="anote_2"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description2</label>
                    <textarea id="anote_description_2" name="note_description_2" rows="4" cols="50" class="form-control"></textarea>

                    </div>
                </div>
                <div class="form-group">
                <div class="form-line">
                    <label>Note 3</label>
                    <input type="text" name="note_3" id="anote_3"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description3</label>
                    <textarea id="anote_description_3" name="note_description_3" rows="4" cols="50"  class="form-control"></textarea>

                    </div>
                </div>

                <div class="form-group">
                <div class="form-line">
                    <label>Note 4</label>
                    <input type="text" name="note_4" id="anote_4"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description4</label>
                    <textarea id="anote_description_4" name="note_description_4" rows="4" cols="50"  class="form-control"></textarea>

                    </div>
                </div>

                <div class="form-group">
                <div class="form-line">
                    <label>Note 5</label>
                    <input type="text" name="note_5" id="anote_5"  class="form-control">
                </div>
                </div>

                <div class="form-group">
                    <div class="form-line">
                        <label>Note  Description5</label>
                    <textarea id="anote_description_5" name="note_description_5" rows="4" cols="50"  class="form-control"></textarea>

                    </div>
                </div>

              
                <!-- <div class="form-group"> -->
                <div class="modal-footer">  
                    <input type="submit" value="Update" class=" btn btn-raised g-bg-cyan">
                    <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                </div>
            </form>
            </div>

        </div>
    </div>
</div>


