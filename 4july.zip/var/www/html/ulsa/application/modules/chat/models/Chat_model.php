<?php    
class Chat_model extends CI_Model
{
    public function __construct()
    {

       
    }
}