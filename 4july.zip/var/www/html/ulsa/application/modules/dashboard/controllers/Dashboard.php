<?php    
class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent:: __construct();
        $this->load->model('Dashboard_model');
        $this->load->helper('url');
        $this->load->library('session');
        
    }

    public function index()
    {
        
        $data['base_url'] = $this->config->item("base_url");
        $data['totalUsers'] = $this->Dashboard_model->countAll_users();
        $data['totalAppointments'] = $this->Dashboard_model->countAll_appointments();
        $data['totalDoctors'] = $this->Dashboard_model->countAll_doctors();
        $data['appointmentList'] = $this->Dashboard_model->getAppointmentList();
        $data['notificationAppt'] = $this->Dashboard_model->getNotificationAppt();
        // print_r($data['appointmentList']); die;
        $this->load->view('header',$data);
        $this->load->view('index',$data);
        $this->load->view('footer',$data);

    }

    public function profile()
    {        
        $data['base_url'] = $this->config->item("base_url");
        $data['profile'] = $this->Dashboard_model->getProfile();
        // print_r($data); die;
        $this->load->view('header',$data);
        $this->load->view('adminprofile',$data);
        $this->load->view('footer',$data);
    }

    public function updateAdmin()
    {
        $id=$this->session->userdata('ulsa_id');
        
        $data=array('name'=>$_POST['name'],'lastname'=>$_POST['lastname'],'email'=>$_POST['email'],'phone'=>$_POST['phone'],'password'=>base64_encode($_POST['password'])
        );

        $this->Dashboard_model->updateAdmin($data,$id);

        echo true;

    }

    public function dashboardStatsData(){
        $data['totalUsers'] = $this->Dashboard_model->countAll_users();
        $data['totalAppointments'] = $this->Dashboard_model->countAll_appointments();
        print_r($data);
    }


}






?>