<?php    
class Dashboard_model extends CI_Model
{
    public function __construct()
    {
        parent:: __construct();
        
    }

    public function getProfile(){

        
       $id= $this->session->userdata('ulsa_id');
        // $this->db->select('name,phone,email');
        $this->db->from('users');
        // $this->db->join('modules_details', 'modules.id = modules_details.module_id');        
        $this->db->where('id',$id);
        $data=$this->db->get();
        return $data->result()[0];
    }

    public function updateAdmin($data,$id){
        $this->db->where('id',$id);
        $this->db->update('users',$data);
    }
    
    public function countAll_users(){
        if ($_SESSION['usertype'] == 2) {
            $this->db->where('desired_clinic', $_SESSION['clinic']);
        }
        $this->db->from('users');
        $this->db->where('users.usertype',3);
        $this->db->where('users.status',1);

        return $this->db->count_all_results();
    }

    public function countAll_appointments(){
        if ($_SESSION['usertype'] == 2) {
            $this->db->where('clinic_id', $_SESSION['clinic']);
        }
        $this->db->from('appointment');
        $this->db->where('DATE(appointment_date)',date('Y-m-d'));
        $this->db->where('status',1);

        return $this->db->count_all_results();
        // print_r($this->db->last_query()); die;
    }

    public function countAll_doctors(){
        if ($_SESSION['usertype'] == 2) {
            $this->db->where('clinic_id', $_SESSION['clinic']);
        }
        $this->db->where('status',1);
        $this->db->from('doctor');
        return $this->db->count_all_results();
    }

    public function getNotificationAppt(){
        $datetime = date("Y-m-d H:i:s");
        $timestamp = strtotime($datetime);
        $time = $timestamp - (3 * 60 *60);
        $datetime = date("Y-m-d H:i:s", $time);
        if ($_SESSION['usertype'] == 2) {
            $this->db->where('appointment.clinic_id', $_SESSION['clinic']);
        }
        
        $this->db->select('appointment.appointment_date,appointment.reminder_date,desired_clinic.desired_clinic AS clinicname,users.name,users.lastname,
        users.email,appointment_type.type');
        $this->db->from('appointment');
        $this->db->join('desired_clinic', 'appointment.clinic_id = desired_clinic.id'); 
        $this->db->join('users', 'appointment.user_id = users.id');
        $this->db->join('appointment_type','appointment.appointment_type = appointment_type.id');
        $this->db->where('appointment.appointment_date > "'.$datetime.'"');
        $this->db->where('appointment.status',1);
        $this->db->order_by("appointment.appointment_date", "desc");
        $this->db->limit(10); 
        return $this->db->get()->result();
        // print_r($this->db->last_query()); die;

    }

    public function getAppointmentList(){
        if ($_SESSION['usertype'] == 2) {
            $this->db->where('appointment.clinic_id', $_SESSION['clinic']);
        }
        $this->db->select('appointment.appointment_date,appointment.reminder_date,desired_clinic.desired_clinic AS clinicname,users.name,users.lastname,
        users.email,users.phone,appointment_type.type');
        $this->db->from('appointment');
        $this->db->join('desired_clinic', 'appointment.clinic_id = desired_clinic.id'); 
        $this->db->join('users', 'appointment.user_id = users.id');
        $this->db->join('appointment_type','appointment.appointment_type = appointment_type.id');
        $this->db->order_by("appointment.appointment_date", "desc");
        $this->db->limit(10); 
        return $this->db->get()->result();
        // print_r($this->db->last_query()); die;







        // $this->db->select('users.*,desired_clinic.desired_clinic ');
        // $this->db->from($this->table);
        // $this->db->join('desired_clinic', 'users.desired_clinic = desired_clinic.id'); 
        // $this->db->join('appointment', 'users.desired_clinic = desired_clinic.id'); 
        // $this->db->from('appointment');
        // return $this->db->count_all_results();
    }
}






?>