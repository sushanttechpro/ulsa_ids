<?php
if (!$this->session->userdata("email")) {
    $this->load->helper('url');
    redirect('auth');
}
?>

<section class="content home">
    <div class="container-fluid">
        <div class="block-header">
            <!-- <h2>Dashboard</h2>
            <small class="text-muted">Welcome to Swift application</small> -->
        </div>
    </div>
    <form method="post" id="admin_update">
    <div class="row clearfix">
        <div class="col-sm-6 ">
            <div class="form-group">
                <div class="form-line">
                    <label>First Name</label>
                    <input style="padding:8px;" type="text" name="name" id="name" required value="<?php echo $profile->name; ?>" class="form-control" maxlength="30">
                </div>
            </div>
        </div>
        <div class="col-sm-6 ">
            <div class="form-group">
                <div class="form-line">
                    <label>Last Name</label>
                    <input style="padding:8px;" type="text" name="lastname" id="lastname" required value="<?php echo $profile->lastname; ?>" class="form-control" maxlength="30">
                </div>
            </div>
        </div>
    </div>

    <div class="row clearfix">
        <div class="col-sm-6 ">
            <div class="form-group">
                <div class="form-line">
                    <label>User Email</label>
                    <input style="padding:8px;" type="email" name="email" id="email" required value="<?php echo $profile->email; ?>" class="form-control">
                </div>
            </div>
        </div>
        <div class="col-sm-6 ">
            <div class="form-group">
                <div class="form-line">
                    <label>User Mobile</label>
                    <input style="padding:8px;" type="phone" name="phone" id="phone" required value="<?php echo $profile->phone; ?>" class="form-control preventAlpha" maxlength="12">
                </div>
            </div>
        </div>
    </div>

    <div class="row clearfix">
        <div class="col-sm-6 ">
            <div class="form-group">
                <div class="form-line">
                    <label>Change Password</label>
                    <input style="padding:8px;" type="Password" name="password" id="Password"   class="form-control " required maxlength="20"> 
                </div>
            </div>
        </div>
        <div class="col-sm-6 ">
            <div class="form-group">
                <div class="form-line">
                    <label>Confirm Password</label>
                    <input style="padding:8px;" type="Password" name="password" id="Password"   class="form-control " required maxlength="20"> 
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="form-group">
        <div class="form-line">
            <label>First Name</label>
            <input style="padding:8px;" type="text" name="name" id="name" required="" value="<?php echo $profile->name; ?>" class="form-control" maxlength="30">
        </div>
    </div>
    <div class="form-group">
        <div class="form-line">
            <label>Last Name</label>
            <input style="padding:8px;" type="text" name="lastname" id="lastname" required="" value="<?php echo $profile->lastname; ?>" class="form-control" maxlength="30">
        </div>
    </div>
    


    <div class="form-group">
        <div class="form-line">
            <label>Email</label>
            <input style="padding:8px;" type="email" name="email" id="email" required="" value="<?php echo $profile->email; ?>" class="form-control">
        </div>
    </div>

    <div class="form-group">
        <div class="form-line">
            <label>Mobile</label>
            <input style="padding:8px;" type="phone" name="phone" id="phone" required="" value="<?php echo $profile->phone; ?>" class="form-control preventAlpha" maxlength="12">
        </div>
    </div>

    <div class="form-group">
        <div class="form-line">
            <label>Change Password</label>
            <input style="padding:8px;" type="Password" name="password" id="Password"   class="form-control " required maxlength="20"> 
        </div>
    </div> -->


    <div class="modal-footer">
        <input type="submit" value="Save" class=" btn btn-raised g-bg-cyan">
        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button> -->
    </div>
    </form>


</section>

<div class="color-bg"></div>