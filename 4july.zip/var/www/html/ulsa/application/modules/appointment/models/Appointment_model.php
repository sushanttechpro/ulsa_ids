<?php    
class Appointment_model extends CI_Model
{
    public function __construct()
    {

        // Set orderable column fields
        $this->table = 'appointment';
        $this->column_order = array( 'name','users.phone','appointment_type.type', 'appointment_state','desired_clinic.desired_clinic','appointment_date','appointment_state');
        // Set searchable column fields
        $this->column_search = array( 'name','users.lastname','family_member.Firstname','family_member.Lastname','appointment_type.type','appointment_state','desired_clinic.desired_clinic','appointment_date','appointment_state','users.phone');
        // Set default order
        $this->order = array('appointment.appointment_date' => 'Desc');
    }
 
    public function getRows_appointment($postData){
        $this->_get_datatables_query_appointment($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $query = $this->db->get();
        return $query->result();
        // print_r($this->db->last_query()); die;
    }
    
    
    public function countAll_appointment(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered_appointment($postData){
        $this->_get_datatables_query_appointment($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    
    private function _get_datatables_query_appointment($postData){
        $this->db->where('users.status', 1);
        $this->db->where('desired_clinic.status', 1);
        $this->db->select('appointment.*,users.name,users.lastname,users.phone,desired_clinic.desired_clinic,appointment_type.type,family_member.Firstname,family_member.Lastname');
        $this->db->from($this->table);

        $this->db->join('users', 'appointment.user_id = users.id', 'left'); 
        $this->db->join('desired_clinic', 'appointment.clinic_id = desired_clinic.id', 'left'); 
        $this->db->join('appointment_type', 'appointment.appointment_type = appointment_type.id', 'left'); 
        $this->db->join('family_member', 'appointment.family_member_id = family_member.member_uniqid', 'left'); 




        if ($_SESSION['usertype'] == 2) {
            $this->db->where('users.desired_clinic', $_SESSION['clinic']);
        }       
         
        // $this->db->from($this->table);
 
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

        
    public function appointmentDetails($id){

        $this->db->select('appointment.*,appointment_type.*,users.name,users.lastname,users.phone,users.email,family_member.Firstname,family_member.Lastname');
        $this->db->from('appointment');
        // $this->db->join('desired_clinic', 'appointment.clinic_id = desired_clinic.id','left'); 
        $this->db->join('appointment_type', 'appointment.appointment_type = appointment_type.id','left'); 
        $this->db->join('users', 'appointment.user_id = users.id', 'left'); 
        $this->db->join('family_member', 'appointment.family_member_id = family_member.member_uniqid', 'left'); 


        $this->db->where('appointment.id',$id);
        $data=$this->db->get()->result();
        return $data;
 
    }
    public function appointmentTime($id){   
        $this->db->select('appointment.*,appointment_time.*');
        $this->db->from('appointment');
        $this->db->join('appointment_time', 'appointment.id = appointment_id','left');
        $this->db->where('appointment.id',$id);
        $data=$this->db->get()->result();
        return $data;
    }

    public function appointmenNote($id)
    {
        $this->db->select('appointment.*,notes.appointment_id,notes.note_name,notes.note_description');
        $this->db->from('appointment');
        $this->db->join('notes', 'appointment.id = notes.appointment_id','left'); 
        $this->db->where('appointment.id',$id);
        $data=$this->db->get()->result();
        return $data;


    }

    public function approve($data,$id)
    {
        $this->db->where('id',$id);
       $q= $this->db->update('appointment',$data);
       if($q==true){
           echo true;
       }else{
           echo false;
       }

    }

  


   
   
  
}
