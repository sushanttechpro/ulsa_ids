<style>
    .ui-timepicker-container{ 
     z-index:9999999 !important; 
}
</style>
<section class="content home">
    <div class="container-fluid">
        <div class="block-header">
            <h2>Appointment Details</h2>
           
        </div>
    </div>
    <?php  foreach ($appointment as $data): ?>
    <div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 ">
				<div class="card">
					<div class="header">
						<!-- <h2>Appointment Information </h2> -->
					</div>
					<div class="body">
                    <?php if(empty($data->Firstname) ){ ?> 
                        <div class="row clearfix">
                            <div class="col-sm-4 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient First Name</label>
                                        <input type="text" class="form-control" value="<?= $data->name ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient Last Name</label>
                                        <input type="text" class="form-control" value="<?= $data->lastname ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient's Email Address</label>
                                        <input type="text" class="form-control" value="<?= $data->email ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php  }?>
                        <?php if(!empty($data->Firstname) ){ ?>                             
                        <div class="row clearfix">
                            <div class="col-sm-4 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient  First Name</label>
                                        <input type="text" class="form-control" value="<?= $data->Firstname ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient  Last Name</label>
                                        <input type="text" class="form-control" value="<?= $data->Lastname ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient's Email Address</label>
                                        <input type="text" class="form-control" value="<?= $data->email ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row clearfix">
                            <div class="col-sm-12 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Appointment Created By</label>
                                        <input type="text" class="form-control" value="<?= $data->name.' '.$data->lastname ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <?php  }?> 
                        <div class="row clearfix">
                            <div class="col-sm-3 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Appointment Created</label>
                                        <input type="text" class="datepicker form-control" value="<?=  date(" j F Y g:i a", strtotime ($data->appointment_date )) ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <?php if(!empty($data->reminder_date)){ ?>
                            <div class="col-sm-3 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Reminder Date</label>
                                        <input type="text" class="datepicker form-control" value="<?=  date(" j F Y g:i a", strtotime ($data->reminder_date )) ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                            <div class="col-sm-3 ">
                            <div class="form-group">
                                    <div class="form-line">
                                        <label>Appointment Type</label>
                                        <input type="text" class="datepicker form-control" value="<?=  $data->type ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Appointment Status</label>
                                        <input type="text" class="datepicker form-control" value="<?=  $data->appointment_state ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient Mobile Number</label>
                                        <input type="text" class="form-control" value="<?= $data->phone ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="row clearfix">
                            <div class="col-sm-3 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="date" name="date" class=" form-control" placeholder="Please choose date" data-id="<?php $id= $data->id?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-3 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="time" name="time" class=" form-control" placeholder="Please choose time" data-id="<?php $id= $data->id?>">
                                    </div>
                                </div>
                            </div>
                        </div> -->

<!-- 
                            <div class="col-sm-3 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="time" name="time" class=" form-control" placeholder="Please choose Time">
                                    </div>
                                </div>
                            </div> 

					</div>
                         <div class="row clearfix"> -->
                            <!-- <div class="col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <label>Patient's Email Address</label>
                                        <input type="text" class="form-control" value="<?= $data->email ?>" readonly>
                                    </div>
                                </div>
                            </div> -->
                            <!-- <div class="col-sm-12">
                                <button type="submit" class="btn btn-raised g-bg-cyan">Submit</button>
                                <button type="submit" class="btn btn-raised">Cancel</button>
                            </div> -->
                        <!-- </div> -->
                    </div>
				</div>
                <div class="card">
                    <div class="header">
						<h2>Patient Notes</h2>
					</div>
                    <div class="body">
                        <div class="row clearfix">
                            <?php foreach ($note as $data): ?>
                                <?php  if(!empty($data->note_name)){ ?>
                                    <div class="col-lg-6 col-md-4 col-sm-12" style="border: 1px solid #cacaca;">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="card-title" style="text-align:center;"><?= $data->note_name ?></h4>
                                                <p class="card-text" style="text-align:justify;"  ><?= $data->note_description ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php } else {?>
                                    <p style="margin-left: 45%;color: #495057;">No Notes Available</p>
                                <?php } ?>
                            <?php endforeach; ?>
                        </div>
					</div>
                </div>
                <div class="card">
                    <div class="header">
						<h2>Patient Availability</h2>
					</div>
                    <div class="body">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Days</th>
                                        <th>Slots</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($appointment_time as $result): ?>
                                <?php 
                                if( $result->days==1){
                                    $choosenDay = "Monday";
                                } else if( $result->days==2){
                                    $choosenDay = "Tuesday";
                                } else if( $result->days==3){
                                    $choosenDay = "Wednesday";
                                    
                                } else if( $result->days==4){
                                    $choosenDay = "Thursday";
                                    
                                } else if( $result->days==5){
                                    $choosenDay = "FridaY";
                                    
                                } else if( $result->days==6){
                                    $choosenDay = "Saturday";
                                    
                                } else if( $result->days==7){
                                    $choosenDay = "Sunday";
                                }
                                if($result->slots == 1){
                                    $choosenSlot = "Anytime";
                                } else if($result->slots == 2){
                                    $choosenSlot = "Morning";
                                } else if($result->slots == 3){
                                    $choosenSlot = "Afternoon";
                                } else if($result->slots == 4){
                                    $choosenSlot = "Evening";
                                } else if($result->slots == 0){
                                    $choosenSlot = "Client didn't choose any option";
                                }
                                if($result->days==0){
                                    $choosenDay = "Next Avail Appt.";
                                    $choosenSlot = "";
                                }
                                ?>
                                <tr>
                                    <td><?= $choosenDay ?></td>
                                    <td><?= $choosenSlot ?></td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
					</div>
                </div>
                <div class="card">
                    <div class="header">
						<h2>Fix Appointment</h2>
					</div>
                    <div class="body">
                        <form id="apfix">
                        <div class="row clearfix">
                            <div class="col-sm-6 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="hidden" id="id" name="id" value="<?php echo $data->id?>">
                                        <input type="text" id="date" name="date" class=" form-control" placeholder="Please choose date" >
                                    </div>
                                </div>
                            </div>
                                
                            <div class="col-sm-6 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" id="time" name="time" class=" form-control" placeholder="Please choose time" >
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <input type="submit" value="Fix Appointment" class=" btn btn-raised g-bg-cyan">
                                <!-- <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button> -->
                            </div>
                        </div>
                        </form>
					</div>
                </div>
			</div>
		</div>
    <?php endforeach;?>
</section>

<div class="color-bg"></div>