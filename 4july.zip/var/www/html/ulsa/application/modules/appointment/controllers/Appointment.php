<?php
class Appointment extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Appointment_model');
        $this->load->helper('url');
        $this->load->library('session');

    }

    public function index()
    {
        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header', $data);
        $this->load->view('index', $data);
        $this->load->view('footer', $data);

    }

    public function fetchAppointment()
    {
        $data = $row = array();
        $rows = $this->Appointment_model->getRows_appointment($_POST);
        $i = $_POST['start'] + 1;
        foreach ($rows as $users) {

            if (empty($users->Firstname)) {
                $data[] = array($i,

                    $users->name . ' ' . $users->lastname,

                    $users->phone, $users->type, $users->desired_clinic, date(" j F Y g:i a", strtotime($users->appointment_date)), $users->appointment_state,

                    // ' <a href="' . $this->config->item("base_url") . 'users/edit_User?id=' . $users->id . ' " class="btn btn-primary edit"> <i class="fa fa-pencil"></i>Edit</a>',
                    ' <a href="' . $this->config->item("base_url") . 'appointment/details?id=' . $users->id . ' " style="color:#212529;"><span class="material-icons makepoint">
                remove_red_eye </span></a>

             <i name="delete" id="' . $users->id . '" class="fa fa-trash-o delete_appointment makepoint" style="margin-left: 20px;" aria-hidden="true"></i>',

                );
                $i++;

            } else {
                $data[] = array($i, $users->Firstname . ' ' . $users->Lastname.

                    '<span data-toggle="tooltip" title=" ' . $users->name . ' ' . $users->lastname . '"><i style="margin-left:10px;" class="fa fa-users " aria-hidden="true"></i> </span>',

                    $users->phone, $users->type, $users->desired_clinic, date(" j F Y g:i a", strtotime($users->appointment_date)), $users->appointment_state,

                    // ' <a href="' . $this->config->item("base_url") . 'users/edit_User?id=' . $users->id . ' " class="btn btn-primary edit"> <i class="fa fa-pencil"></i>Edit</a>',
                    ' <a href="' . $this->config->item("base_url") . 'appointment/details?id=' . $users->id . ' " style="color:#212529;"><span class="material-icons makepoint">
            remove_red_eye </span></a>

         <i name="delete" id="' . $users->id . '" class="fa fa-trash-o delete_appointment makepoint" style="margin-left: 20px;" aria-hidden="true"></i>',

                );
                $i++;
            }
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Appointment_model->countAll_appointment($_POST),
            "recordsFiltered" => $this->Appointment_model->countFiltered_appointment($_POST),
            "data" => $data,
        );
        echo json_encode($output);
    }
    public function details()
    {
        $id = $_GET['id'];

       


        $data['note'] = $this->Appointment_model->appointmenNote($id);
        $data['appointment_time'] = $this->Appointment_model->appointmentTime($id);
        $data['appointment'] = $this->Appointment_model->appointmentDetails($id);
        $data['base_url'] = $this->config->item("base_url");
        $data['id'] = $_GET['id'];
        // print_r($data['appointment']); die;
        $this->load->view('header', $data);
        $this->load->view('view', $data);
        $this->load->view('footer', $data);
    }

    public function fixAppointment()
    {
       

        $id = $_POST['id'];
        // $date=$_POST['date'];

        $start_date = date("Y-m-d", strtotime($_POST['date'])).' '.$_POST['time']; 

        // $start_date = date("Y-m-d ", strtotime($date));
        $data=array('approved_status'=>1,'admin_approved_date'=>$start_date);
        $this->Appointment_model->approve($data,$id);


    
   
    }

}
