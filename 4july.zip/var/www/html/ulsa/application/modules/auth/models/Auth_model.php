<?php    
class Auth_model extends CI_Model
{
    public function __construct()
    {
        parent:: __construct();
     
        
    }
   

    public function check_user_id($email)
    {
        $sql = "SELECT count(*) as count From users Where email = '$email'";
        $select = $this->db->query($sql);
        echo $select->result_array()[0]['count'];
       
    }

    public function select_email_login($email_address, $password)
    {
       
        $this->db->where('email', $email_address);
        $this->db->where('password', $password);
        $result = $this->db->get('users')->result();
        $clinic_id=$result[0]->desired_clinic;
        $this->db->where('id',$clinic_id);
        $r = $this->db->get('desired_clinic')->result();
        if(empty($r)){
                $des_clinic = '';
        } else {
            $des_clinic = $r[0]->desired_clinic;

        } 

        // $clinic_name=$this->db->get_where('desired_clinic',array('id'=>$clinic_id))->result()[0]->desired_clinic; 
     
        if ($result) {
            $session_data = array(
                'ulsa_id' => $result[0]->id,
                'name' => $result[0]->name,
                'lastname' => $result[0]->lastname,
                'email' => $result[0]->email,
                'usertype'=>$result[0]->usertype,
                'clinic' => $result[0]->desired_clinic,
                'clinic_name'=>$des_clinic
                 );

            $this->session->set_userdata($session_data);
            echo 1;
        } else {
            echo 0;
        }
    }

    


   
  
}






?>