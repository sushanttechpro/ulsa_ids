</div>
<script src="<?php echo $base_url; ?>assets/js/jquery.min.js"></script>

  <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/calendar/calendar.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/cards/basic.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/charts/chartjs.min.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/charts/sparkline.min.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/forms/basic-form-elements.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/forms/editors.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/maps/jvectormap.js"></script>
 <!-- <script src="<?php echo $base_url; ?>assets/js/pages/tables/jquery-datatable.js"></script> -->
 <script src="<?php echo $base_url; ?>assets/js/pages/ui/animations.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/ui/dialogs.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/ui/modals.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/ui/notifications.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/ui/range-sliders.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/ui/sortable-nestable.js"></script>
 <script src="<?php echo $base_url; ?>assets/js/pages/index.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/autosize/autosize.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/bootstrap-notify/bootstrap-notify.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/chartjs/Chart.bundle.min.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/ckeditor/ckeditor.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/dropzone/dropzone.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/ion-rangeslider/js/ion.rangeSlider.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/jquery-countto/jquery.countTo.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/momentjs/moment.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/nestable/jquery.nestable.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/sweetalert/sweetalert.min.js"></script>
 <script src="<?php echo $base_url; ?>assets/plugins/waitme/waitMe.js"></script>

 <script src="<?php echo $base_url; ?>assets/bundles/chartscripts.bundle.js"></script> <!-- Chart Plugins Js -->

<!-- <script src="<?php echo $base_url; ?>assets/bundles/datatablescripts.bundle.js"></script> Chart Plugins Js -->

<script src="<?php echo $base_url; ?>assets/bundles/fullcalendarscripts.bundle.js"></script> 

<script src="<?php echo $base_url; ?>assets/bundles/jvectormapscripts.bundle.js"></script> <!-- Chart Plugins Js -->


<script src="<?php echo $base_url; ?>assets/bundles/sparklinescripts.bundle.js"></script> <!-- Chart Plugins Js -->

<script src="<?php echo $base_url; ?>assets/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
 
<script src="<?php echo $base_url; ?>assets/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js --> 

<script src="<?php echo $base_url; ?>assets/bundles/datatablescripts.bundle.js"></script>

<script src="<?php echo $base_url; ?>assets/bundles/mainscripts.bundle.js"></script><!-- Custom Js -->

<script src="<?php echo $base_url; ?>assets/js/morphing.js"></script><!-- Custom Js --> 

<script src="<?php echo $base_url; ?>assets/js/timepicker.min.js"></script>

<!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
  <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.9/datepicker.min.js"></script> -->

 <script src="<?php echo $base_url; ?>assets/js/date.js"></script>
<script src="<?php echo $base_url; ?>assets/js/main.js"></script>


<!-- <script src="<?php echo $base_url; ?>assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>  -->

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-datetimepicker/2.7.1/js/bootstrap-material-datetimepicker.js"></script> 

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-datetimepicker/2.7.1/js/bootstrap-material-datetimepicker.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-datetimepicker/2.7.1/js/bootstrap-material-datetimepicker.min.js.map"></script>  -->




 </body>
</html>









 
























</body>
</html>