var base_jsurl = "http://142.93.211.14/ulsa/";
var url = $(location).attr('href');
var parts = url.split("/");
var dashPart = parts[4].replace(/#/, "");
var last_part = parts[parts.length - 1];

$(document).ready(function() {
    "use strict";

    // ______________ PAGE LOADING
    $(window).on("load", function(e) {
        $("#global-loader").fadeOut("slow");
    })

    // ______________ BACK TO TOP BUTTON

    $(window).on("scroll", function(e) {
        if ($(this).scrollTop() > 300) {
            $('#back-to-top').fadeIn('slow');
        } else {
            $('#back-to-top').fadeOut('slow');
        }
    });

    $("#back-to-top").on("click", function(e) {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    $(".readonly").keydown(function(e) {
        e.preventDefault();
    });



    ////*****************////
    //// WHITE SPACE CHECK ////
    $("input").on("keypress", function(e) {
        if (e.which === 32 && !this.value.length)
            e.preventDefault();
    });

    $("textarea").on("keypress", function(e) {
        if (e.which === 32 && !this.value.length)
            e.preventDefault();
    });

    ////*****************////
    //// IS NUMBER CHECK ////
    $("body").on("keypress", ".telephone, .activationSet", function(event) {
        return isNumber(event, this)

    })

    ////Prevent Number////
    $(".preventNumber").on('input', function(event) {
        this.value = this.value.replace(/[^a-z\s]/gi, '');
    });
    ////Prevent Letters////
    $(".preventAlpha").on('input', function(event) {
        this.value = this.value.replace(/[^0-9]/gi, '');


    });

    function isNumber(evt, element) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if ((charCode == 32 || $(element).val().indexOf(' ') == -1) && (charCode != 43 || $(element).val().indexOf('+') != -1) && (charCode < 48 || charCode > 57) && charCode !== 8)
            return false;
        return true;
    }

    // http://localhost/survey





    ////******************////
    //// USER LOGIN CHECK ////
    $("#email_address").on('blur', function() {
        var email_address = $("#email_address").val();
        $.ajax({
            url: base_jsurl + 'auth/check_user_id',
            type: 'POST',
            data: { email_address: email_address },
            success: function(data) {
                if (data == 0) {
                    $(".errLoginUser").text("Invalid Email");
                    $(".errLoginUser").css("display", "block");
                    return false;
                } else {
                    $(".errLoginUser").css("display", "none");
                    return true;
                }
            }
        })
    })



    ////***************////
    // LOGIN FORM//
    $("#login").on('submit', function(e) {
        e.preventDefault();

        var email_address = $("#email_address").val();
        var password = $("#userPassword").val();
        // var remember = $('#rememberme').is(':checked');

        $(".errLoginUser").css("display", "none");
        $(".errLoginPass").css("display", "none");
        $.ajax({
            url: base_jsurl + 'auth/check_user_id',
            type: 'POST',
            data: { email_address: email_address },
            success: function(data) {
                if (data == 0) {
                    $(".errLoginUser").text("Invalid Email");
                    $(".errLoginUser").css("display", "block");
                    return false;
                } else {
                    $(".errLoginUser").css("display", "none");
                    $.ajax({
                        url: base_jsurl + 'auth/check_email_login',
                        type: 'POST',
                        data: { email_address: email_address, password: password },
                        success: function(data) {
                            if (data == 1) {
                                $(".errLoginUser").css("display", "none");
                                $(".errLoginPass").css("display", "none");
                                window.location.replace(base_jsurl + "dashboard")

                            } else {
                                $(".errLoginPass").text("Invalid Password");
                                $(".errLoginPass").css("display", "block");
                                return false;
                            }
                        }
                    })
                }
            }
        })
    })

    ////****************////
    //// RESET PASSWORD ////
    $("#resetPasswordForm").on('submit', function(e) {
        e.preventDefault();
        $(".errResetEmail").css("display", "none");
        $.ajax({
            url: base_jsurl + 'auth/reset_pass_link',
            type: 'POST',
            data: $("#resetPasswordForm").serialize(),
            success: function(data) {
                if (data == 1) {
                    swal({
                        title: "Um link para recuperar a sua password foi enviado para o seu email.",
                        type: "success",
                        confirmButtonText: "OK"
                    }, function() {
                        window.location.href = base_jsurl + "auth/login";
                    });
                } else if (data == 0) {
                    $(".errResetEmail").text("Email inválido.");
                    $(".errResetEmail").css("display", "block");
                    return false;
                }
            }
        })
    })

    $("#passwordForm").on('submit', function(e) {
        e.preventDefault();
        if ($("#password").val() != $("#confPassword").val()) {
            $(".errResetPassword").css("display", "block");
        } else {
            $(".errResetPassword").css("display", "none");
            var abc = $(this).find("button[type=submit]").attr("attrb");
            // var id = $("input[type=submit]").attr("attrb")
            $.ajax({
                url: base_jsurl + 'auth/reset_pass',
                type: 'POST',
                data: $("#passwordForm").serialize(),
                success: function(data) {
                    if (data == 1) {
                        if (abc == "web") {
                            swal({
                                title: "A password foi alterada com sucesso.",
                                type: "success",
                                confirmButtonText: "OK"
                            }, function() {
                                window.location.href = base_jsurl + "auth/login";
                            });
                        } else {
                            swal({
                                title: "A password foi alterada com sucesso.",
                                type: "success",
                                confirmButtonText: "OK"
                            }, function() {
                                window.location.href = base_jsurl + "auth/pass_change_msg";
                            });
                        }

                    }
                }
            })
        }
    })

    ////***************////
    // Users Table//
    $('#users_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'users/fetchUsers',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [6, 0],

            "orderable": false
        }]
    });


    // Delete User//
    $(document).on("click", '.deleteuser', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this patient?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'users/deleteUser',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "users")
                            }
                        }
                    })
                }
            });
    })

    //Users Satus Chane Toggle button//
    $('body').on('change', '#userstatus', function() {
        var id = $(this).attr("data-user_toggle");
        if ($(this).prop("checked") == true) {
            var prop = $(this).prop("checked")
        } else {
            var prop = $(this).prop("checked")
        }
        $.ajax({
            url: base_jsurl + 'users/change_user_status',
            type: 'POST',
            data: { prop: prop, id: id },
            success: function(data) {}
        })

    });


    ////***************////
    // Add Users//
    $('#add_user').submit(function(e) {
        e.preventDefault();
        var formName = $(this);

        $(".errEmail").css("display", "none");
        $.ajax({
            url: base_jsurl + 'users/checkEmail',
            type: 'post',
            datatype: 'json',
            data: $(this).serialize(),
            data: { email: $("#email").val() },
            success: function(data) {
                if (data == 1) {
                    $(".errEmail").text("Email already exist");
                    $(".errEmail").css("display", "block");
                    // window.location.replace(base_jsurl + "users")
                } else if (data == 0) {
                    $(".errEmail").css("display", "none");
                    $(".errMobile").css("display", "none");
                    $.ajax({
                        url: base_jsurl + 'users/checkMobile',
                        type: 'post',
                        datatype: 'json',
                        data: $(this).serialize(),
                        data: { phone: $("#phone").val() },
                        success: function(data) {
                            // alert(data);
                            if (data == 1) {
                                $(".errMobile").text("Mobile  already exist");
                                $(".errMobile").css("display", "block");
                            } else {
                                $.ajax({
                                    url: base_jsurl + 'users/insertUser',
                                    type: 'post',
                                    datatype: 'json',
                                    // data: $(this).serialize(),
                                    data: formName.serialize(),
                                    success: function(data) {
                                        if (data == true) {
                                            // window.location.replace(base_jsurl + "users")
                                            swal("Created!", "User Created Successfully.", "success")
                                            setTimeout(function() {
                                                window.location.reload();
                                            }, 2000);

                                        }
                                    }
                                });

                            }
                        }

                    });



                }


            }



        });
    });

    ///Update Admin Profile///
    $('#users_update').submit(function(e) {
        e.preventDefault();
        var form = $('#users_update')[0];
        var formData = new FormData(form);
        // var notification = $('#push_notification_state').val();
        // alert(notification);

        $.ajax({
            url: base_jsurl + 'users/updateUser',
            type: 'post',
            datatype: 'json',
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {

                    swal("Updated!", "Patient Profile Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);

                }
            }
        });
    });



    var switchStatus = 1;
    $("#push_notification").on('change', function() {
        if ($(this).is(':checked')) {
            return $(this).is(':checked');
            // alert(switchStatus); // To verify
            // return 1;
        } else {
            return $(this).is(':checked');
            // alert(switchStatus); // To verify
            // return 0;
        }
    });


    ////***************////
    // Dentistry_table Table//
    $('#dentistry_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'dentistry/fetchDentistry',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [4],

            "orderable": false
        }]

    });

    // Delete Dentistry//
    $(document).on("click", '.delete_dentistry', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this dentistry?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'dentistry/deleteDentistry',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {

                                swal("Deleted!", "Dentistry Deleted Successfully.", "success")
                                setTimeout(function() {
                                    // window.location.reload();
                                    window.location.replace(base_jsurl + "dentistry")

                                }, 2000);
                            }
                        }
                    })
                }
            });
    });


    ///Add dentistry///
    $('#add_Dentistry').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description'].getData();
        var form = $('#add_Dentistry')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);
        $.ajax({
            url: base_jsurl + 'dentistry/addDentistry',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "dentistry")
                    swal("Created!", "Dentistry Created Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);

                }
            }
        });
    });


    ////***************////
    //Edit Dentistry popup//
    $(document).on('click', '.edit_dentistry', function() {

        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'dentistry/editDentistry',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editModal').modal('show');
                $('#id').val(id);
                $('#clinic_id_dentistry').val(data.clinic_id);
                $('#clinic_latitude').val(data.latitude);
                $('#clinic_longitude').val(data.longitude);



                // $('#image_dentistry').val(data.image);
                $('#General_dentistry').val(data.General_dentistry_name);
                // $('#description_dentistry').val(data.description);
                CKEDITOR.instances['description_dentistry'].setData(data.description);

            }
        })
    });

    $('#edit_Dentistry').submit(function(e) {
        // console.log(CKEDITOR.instances['description_dentistry'].getData());
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description_dentistry'].getData();
        var form = $('#edit_Dentistry')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);
        $.ajax({
            url: base_jsurl + 'dentistry/updateDentistry',
            type: 'post',
            datatype: 'json',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    swal("Updated!", "Dentistry Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    ////Add Braces///
    $('#add_braces').submit(function(e) {
        e.preventDefault();
        var form = $('#add_braces')[0];
        var formData = new FormData(form);
        $.ajax({
            url: base_jsurl + 'braces/add_braces',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "braces")
                    swal("Created!", "Braces Created Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });



    ////***************////
    //Edit Braces popup//
    $(document).on('click', '.edit_brace', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'braces/edit_braces',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editModal').modal('show');
                $('#id').val(id);
                // $('#image_dentistry').val(data.image);
                $('#braces_name').val(data.Braces_post_op);
                $('#bclinic_id').val(data.clinic_id);

                $('#youlink').val(data.link);


            }
        })
    });

    $('#edit_braces').submit(function(e) {
        e.preventDefault();
        var form = $('#edit_braces')[0];
        var formData = new FormData(form);
        $.ajax({
            url: base_jsurl + 'braces/update_braces',
            type: 'post',
            datatype: 'json',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "braces")
                    swal("Updated!", "Braces Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    ////Delete Braces////
    $(document).on("click", '.delete_braces', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this Braces-Post OP ?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'braces/delete_braces',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "braces")
                            }
                        }
                    })
                }
            });
    });

    ////***************////
    // Doctor_table //
    $('#doctors_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'doctors/fetchDoctors',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [5, 6],

            "orderable": false
        }]

    });


    ////Add Doctor////
    $('#add_Doctor').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description'].getData();
        var form = $('#add_Doctor')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'doctors/addDoctor',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "doctors")
                    swal("Created!", "Doctor Created Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    ////***************////
    //Edit Doctor popup//
    $(document).on('click', '.edit_doctor', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'doctors/editDoctor',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editDoctor').modal('show');
                $('#id').val(id);
                $('#doctor_name').val(data.name);
                $('#doctor_phone').val(data.phone);

                $('#cclinic_id').val(data.clinic_id);

                CKEDITOR.instances['doctor_description'].setData(data.doctor_description);

            }
        })
    });


    $('#edit_Doctor').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['doctor_description'].getData();
        var form = $('#edit_Doctor')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'doctors/updateDoctor',
            type: 'post',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "doctors")
                    swal("Updated!", "Doctor Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });

    // Delete Doctors//
    $(document).on("click", '.delete_doctor', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this doctor?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'doctors/deleteDoctor',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "doctors")
                            }
                        }
                    })
                }
            });
    })


    //Doctor Satus Chane Toggle button//
    $('body').on('change', '#doctorstatus', function() {
        var id = $(this).attr("data-user_toggle");
        if ($(this).prop("checked") == true) {
            var prop = $(this).prop("checked")
        } else {
            var prop = $(this).prop("checked")
        }
        $.ajax({
            url: base_jsurl + 'doctors/change_dctor_status',
            type: 'POST',
            data: { prop: prop, id: id },
            success: function(data) {}
        })

    });

    // Members Table//
    $('#members_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        // "info": false,
        // "lengthChange": false,
        // "ordering": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'users/fetch_member',
            "type": "POST",
            'data': { "id": $("#members_table").attr("data-id") }
        },
        "columnDefs": [{
            "targets": [3],

            "orderable": false
        }]
    });

    ////***************////
    // Add Member   //
    $('#add_member').submit(function(e) {
        // alert("gdbjhdf");

        e.preventDefault();
        $.ajax({
            url: base_jsurl + 'users/insertMember',
            type: 'post',
            datatype: 'json',
            data: $(this).serialize(),
            success: function(data) {
                if (data == true) {
                    swal("Added!", "Family member Added Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    // Delete Member//
    $(document).on("click", '.delete_member', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this member?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'users/deleteMember',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                swal("Deleted!", "Family member Deleted Success.", "success")
                                setTimeout(function() {
                                    window.location.reload();
                                }, 2000);
                            }
                        }
                    })
                }
            });
    })


    ////***************////
    //Edit Member popup//
    $(document).on('click', '.edit_member', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'users/editMember',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#edit_member').modal('show');
                $('#member_id').val(id);
                // $('#image_dentistry').val(data.image);
                $('#member_Firstname').val(data.Firsttname);
                $('#member_Lastname').val(data.Lastname);
                $('#member_phone_number').val(data.phone_number);



            }
        })
    });


    // Braces_table //
    $('#braces_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'braces/fetchBraces',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [3],

            "orderable": false
        }]

    });

    ///SubAdmin table////
    $('#subadmin_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'subadmin/fetchSubadmin',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [5],

            "orderable": false
        }]

    });


    $('#add_subadmin').submit(function(e) {
        e.preventDefault();
        var formName = $(this);

        $(".errEmailsubadmin").css("display", "none");
        $.ajax({
            url: base_jsurl + 'users/checkEmail',
            type: 'post',
            datatype: 'json',
            data: $(this).serialize(),
            data: { email: $("#email").val() },
            success: function(data) {
                if (data == 1) {
                    $(".errEmailsubadmin").text("Email already exist");
                    $(".errEmailsubadmin").css("display", "block");
                    // window.location.replace(base_jsurl + "users")
                } else if (data == 0) {
                    $(".errEmailsubadmin").css("display", "none");
                    $(".errMobilesubadmin").css("display", "none");
                    $.ajax({
                        url: base_jsurl + 'users/checkMobile',
                        type: 'post',
                        datatype: 'json',
                        data: $(this).serialize(),
                        data: { phone: $("#phone").val() },
                        success: function(data) {
                            // alert(data);
                            if (data == 1) {
                                $(".errMobilesubadmin").text("Mobile  already exist");
                                $(".errMobilesubadmin").css("display", "block");
                            } else {
                                $.ajax({
                                    // url: base_jsurl + 'users/insertUser',
                                    url: base_jsurl + 'subadmin/insertUser',
                                    type: 'post',
                                    datatype: 'json',
                                    // data: $(this).serialize(),
                                    data: formName.serialize(),
                                    success: function(data) {
                                        if (data == true) {
                                            // window.location.replace(base_jsurl + "subadmin")
                                            swal("Created!", "User Created Successfully.", "success")
                                            setTimeout(function() {
                                                window.location.reload();
                                            }, 2000);
                                        }
                                    }
                                });

                            }
                        }

                    });



                }


            }



        });
    });




    // Delete subadmin//
    $(document).on("click", '.deletesubadmin', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this subadmin?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'subadmin/deleteSubadmin',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "subadmin")
                            }
                        }
                    })
                }
            });
    })

    ////***************////
    //Edit SubAdmin popup//
    $(document).on('click', '.editsubadmin', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'subadmin/editSubadmin',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#edit_subadmin').modal('show');
                $('#id').val(id);
                // $('#image_dentistry').val(data.image);
                $('#sname').val(data.name);
                $('#semail').val(data.email);
                $('#sphone').val(data.phone);
                $('#slastname').val(data.lastname);
                $('#sdesired_clinic').val(data.desired_clinic);

            }
        })
    });


    $('#update_subadmin').submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: base_jsurl + 'subadmin/updateSubadmin',
            type: 'post',
            datatype: 'json',
            data: $(this).serialize(),
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "subadmin")
                    swal("Updated!", "User Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });

    // clinic_table //
    $('#clinic_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'clinic/fetchClinic',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [6, 7],

            "orderable": false
        }]

    });


    // Delete Clnic//
    $(document).on("click", '.delete_clinic', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this clinic?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'clinic/deleteClinic',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "clinic")
                            }
                        }
                    })
                }
            });
    })


    ////***************////
    //Edit Clinic popup//
    $(document).on('click', '.edit_clinic', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'clinic/editClinic',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editModal').modal('show');
                $('#id').val(id);
                $('#cdesired_clinic').val(data.desired_clinic);
                $('#cclinic_email').val(data.clinic_email);
                $('#cclinic_phoneno').val(data.clinic_phoneno);
                $('#cclinic_address').val(data.clinic_address);
                CKEDITOR.instances['cworking_hours'].setData(data.working_hours);


            }
        })
    });

    $('#edit_clinic').submit(function(e) {

        // alert(Ck_editor_value);
        // var editor = CKEDITOR.editor.replace('doctor_description');
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['cworking_hours'].getData();
        var form = $('#edit_clinic')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'clinic/updateClinic',
            type: 'post',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "clinic")
                    swal("Updated!", "Clinic Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);

                }
            }
        });
    });


    ///Add Clinic///
    $('#add_clinic').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['working_hours'].getData();
        var form = $('#add_clinic')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'clinic/addClinic',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "clinic")
                    swal("Created!", "Clinic Created Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    ///Update Admin Profile///
    $('#admin_update').submit(function(e) {
        e.preventDefault();
        var form = $('#admin_update')[0];
        var formData = new FormData(form);

        $.ajax({
            url: base_jsurl + 'dashboard/updateAdmin',
            type: 'post',
            datatype: 'json',
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {

                    swal("Updated!", "Your Profile Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);

                }
            }
        });
    });

    ///Offers Table/////
    $('#offers_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'offers/fetchOffers',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [4],

            "orderable": false
        }]

    });


    ///Add Offers///
    $('#add_offers').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description'].getData();
        var form = $('#add_offers')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);
        $.ajax({
            url: base_jsurl + 'offers/addOffer',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "offers")
                    swal("Created!", "Offer Created Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    ////***************////
    //Edit offers popup//
    $(document).on('click', '.edit_offers', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'offers/editOffer',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editModal').modal('show');
                $('#id').val(id);
                $('#offer_name').val(data.name);
                $('#offer_clinic_id').val(data.clinic_id);
                CKEDITOR.instances['offer_description'].setData(data.description);


            }
        })
    });



    $('#edit_offers').submit(function(e) {

        // alert(Ck_editor_value);
        // var editor = CKEDITOR.editor.replace('doctor_description');
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['offer_description'].getData();
        var form = $('#edit_offers')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'offers/updateOffer',
            type: 'post',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                if (data == true) {
                    // window.location.replace(base_jsurl + "offers")
                    swal("Updated!", "Offer Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);
                }
            }
        });
    });


    // Delete Offers//
    $(document).on("click", '.delete_offers', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this offer?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'offers/deleteOffer',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "offers")
                            }
                        }
                    })
                }
            });
    })

    // Appointment_table //
    $('#appointment_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'appointment/fetchAppointment',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [0, 7],

            "orderable": false
        }]

    });




    // Appointment type//
    $('#appointment_type').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "bInfo": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'clinic/FetchAppointmenttype',
            "type": "POST",
            'data': { "id": $("#appointment_type").attr("data-id") }
        },
        "columnDefs": [{
            "targets": [1],

            "orderable": false
        }]
    });


    ///Add Appointmnet Type///
    $('#add_aptype').submit(function(e) {
        e.preventDefault();
        var form = $('#add_aptype')[0];
        var formData = new FormData(form);

        $.ajax({
            url: base_jsurl + 'clinic/insertAppointmenttype',
            type: 'post',
            datatype: 'json',
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {

                    swal("Created!", "Appointment type Created Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);

                }
            }
        });
    });

    ////***************////
    //Edit offers popup//
    $(document).on('click', '.edit_aptype', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'clinic/editAppointmenttype',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editModal').modal('show');
                $('#aid').val(id);
                $('#atype').val(data.type);
                $('#anote_1').val(data.note_1);
                $('#anote_2').val(data.note_2);
                $('#anote_3').val(data.note_3);
                $('#anote_4').val(data.note_4);
                $('#anote_5').val(data.note_5);
                $('#anote_description_1').val(data.note_description_1);
                $('#anote_description_2').val(data.note_description_2);
                $('#anote_description_3').val(data.note_description_3);
                $('#anote_description_4').val(data.note_description_4);
                $('#anote_description_5').val(data.note_description_5);
            }
        })
    });


    ///Edit Appointmnet Type///




    // Delete Appointmnet Type//
    $(document).on("click", '.delete_aptype', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this Appointment Type?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'clinic/deleteAppointmenttype',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                swal("Deleted!", "Appointment type Deleted Successfully.", "success")
                                setTimeout(function() {
                                    window.location.reload();
                                }, 2000);
                            }
                        }
                    })
                }
            });
    })

    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });

    // $('#time').bootstrapMaterialDatePicker({
    //     format: 'YYYY-MM-DD HH:mm'
    // });


    $(function() {
        $("#date").datepicker();
        $("#time").timepicker({
            timeFormat: 'H:mm:ss '
                //  z-index:1151 !important; 
        });
        // $("#time").css("z-index", "9999999")
    });

    // $(function() {
    //     $("#time").timepicker();
    // });

    // $(function() {
    //     $("#time").datepicker();
    // });
    // $('#date').change(function() {
    //     var date = $("#date");
    //     // alert(date);
    //     id = $("#date").attr("id");
    //     alert('id');

    //     $.ajax({
    //         url: base_jsurl + 'appointment/date',
    //         type: 'post',
    //         datatype: 'json',
    //         data: { "id": $("#date").attr("data-id"), 'date': date },

    //         // { "id": $("#members_table").attr("data-id") }
    //         success: function(data) {
    //             if (data == true) {
    //                 swal("Update", "Approved ", "success")
    //                 setTimeout(function() {
    //                     window.location.reload();
    //                 }, 2000);
    //             }

    //         }
    //     });
    // });

    $('#apfix').submit(function(e) {
        e.preventDefault();
        var form = $('#apfix')[0];
        var formData = new FormData(form);

        $.ajax({
            url: base_jsurl + 'appointment/fixAppointment',
            type: 'post',
            datatype: 'json',
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {

                    swal("Updated!", "Appointment Fixed Updated Successfully.", "success")
                    setTimeout(function() {
                        window.location.reload();
                    }, 2000);

                }
            }
        });
    });






});