<?php    
class Notification_model extends CI_Model
{
    public function __construct()
    {

     
    }

}