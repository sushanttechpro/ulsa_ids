<section class="content home">
<div class="container-fluid">
        <div class="block-header">
            <h2>User list</h2>
            <!-- <small class="text-muted">Welcome to Swift application</small> -->
        </div>

        <!-- <div class="row clearfix">  -->
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                <div style="padding-bottom: 0px !important;" class="header">
                        <h2 style="width:50%; float:left;"></h2>
                   

                        <!-- <button type="button" class="btn btn-default waves-effect m-r-20" data-toggle="modal" data-target="#defaultModal">Add Sub Admin</button> -->

                       
                    </div>
                    <div class="body table-responsive">
                        <table class="table table-bordered table-striped table-hover js-basic-example dataTable"  id="chatuser_table">
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Clinic</th>
                                    <th>Chat</th>
                                    <!-- <th>Delete</th> -->
                                   
                                </tr>
                            </thead>
                        
                       
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



</section>

<div class="color-bg"></div>