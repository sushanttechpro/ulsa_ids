<?php    
class Dentistry extends CI_Controller
{
    public function __construct()
    {
        parent:: __construct();
        $this->load->model('Dentistry_model');
        $this->load->helper('url');
        $this->load->library('session');
        
    }

    public function index()
    {
        

        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header',$data);
        $this->load->view('index',$data);
        $this->load->view('footer',$data);
        
    }

    public function fetch_Dentistry()
    {
        $data = $row = array();
        $rows = $this->Dentistry_model->getRows_dentistry($_POST);
        foreach ($rows as $users) {
            $data[] = array(  '<img src="'.$users->image.' " width="100" height="100"> ', 
           $users->General_dentistry_name,$users->description,
            // ' <a href="' . $this->config->item("base_url") . 'users/edit_User?id=' . $users->id . ' " class="btn btn-primary edit"> <i class="fa fa-pencil"></i>Edit</a>',
 
         '<button type="button" name="update" id="'.$users->id.'" class="btn btn-success edit_dentistry ">Edit</button>',
        '<button type="button" name="delete" id="'.$users->id.'" class="btn  text-white btn-raised bg-red btn-sm waves-effect  delete_dentistry"><span class="material-icons">
        delete
        </span>Delete</button>',
  
         );
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Dentistry_model->countAll_dentistry($_POST),
            "recordsFiltered" => $this->Dentistry_model->countFiltered_dentistry($_POST),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function delete_Dentistry()
    {
        $id=$_POST['id'];
        $this->Dentistry_model->delete_Dentistry($id);
         echo true;

    }

    public function add_Dentistry()
    {  
        // print_r($_FILES) ;  die;
        $config['upload_path'] = './assets/images/dentistry/';  
        $config['allowed_types'] = 'jpg|jpeg|png|gif';  
        $this->load->library('upload', $config);  
        if(!$this->upload->do_upload('image'))  
        {  
            echo $this->upload->display_errors();  
        }  
        else  
        {  
            $data = $this->upload->data();  

            $picture = array(
            'image'=>'assets/images/dentistry/'.$data['file_name'],'General_dentistry_name'=>$_POST['General_dentistry_name'],
            'description'=>$_POST['Ck_editor_value']       
                );
        $this->Dentistry_model->add_Dentistry($picture);
        echo true;
        } 
    }

    public function edit_Dentistry()
    {

        $output = array();  
        $data = $this->Dentistry_model->edit_dentistry($_POST["id"]);  
        foreach($data as $row)  
        {
             $output['id']=$row->id;
             $output['image'] = $row->image;  
             $output['General_dentistry_name'] = $row->General_dentistry_name;  
             $output['description'] = $row->description;  


            //  echo $row->category_name or die;
        }  
        echo json_encode($output);

    }

    public function update_Dentistry()
    {
        // $data=array('image'=>)
        $id=$_POST['id'];

        $this->db->where('id',$id);
        $q=  $this->db->get('General_dentistry_table')->result()[0];
        $p=$q->{'image'};
        unlink(FCPATH.'/'.$p);


        $config['upload_path'] = './assets/images/dentistry/';  
        $config['allowed_types'] = 'jpg|jpeg|png|gif';  
        $this->load->library('upload', $config);  
        if(!$this->upload->do_upload('image'))  
        {  
            echo $this->upload->display_errors();  
        }  
        else  
        {  
            $data = $this->upload->data();  

            $picture = array(
            'image'=>'assets/images/dentistry/'.$data['file_name'],'General_dentistry_name'=>$_POST['General_dentistry_name'],
            'description'=>$_POST['Ck_editor_value']       
                );
        $this->Dentistry_model->update_Dentistry($picture,$id);
        echo true;

            
        }
    }


   
     
  


}






?>