<script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<style>
    .cke_chrome {
        margin-left: 45px !important;
    }
    .cke_bottom {
        display:none;
    }
</style>
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <!-- <h2>Payments</h2> -->
            <!-- <small class="text-muted">Welcome to Swift application</small> -->
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>Dentistry</h2>

                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addModal">Add Dentistry</button>

                    </div>
                    <div class="body table-responsive">
                        <table class="table table-bordered table-striped table-hover js-basic-example dataTable" id="dentistry_table">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Dentistry</th>
                                    <th>Description</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="color-bg"></div>




<div class="modal fade" id="addModal" tabindex="-1" role="dialog"  >
    <div class="modal-dialog" role="document" style="max-width:75%">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Add Dentistry</h4>
            </div>

            <form id="add_Dentistry" enctype="multipart/form-data" method="post">
                <div class="form-group">
                    <label>Dentistry Name</label>
                    <input type="text" name="General_dentistry_name" id="General_dentistry_name" required>
                </div>
                <div class="form-group">
                    <label>Images</label>
                    <input type="file" name="image" id="image" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea id="description" name="description" rows="4" cols="50" required></textarea>

                    <script type="text/javascript">
                        CKEDITOR.replace('description', {
                            height: 200,
                            width : 900
                        });
                    </script>
                </div>
                <div class="form-group">
                    <input type="submit" value="Add" class="btn btn-primary">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                </div>
            </form>

        </div>
    </div>
</div>




<div class="modal fade" id="editModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" style="max-width:75% !important;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Update Dentistry</h4>
            </div>

            <form id="edit_Dentistry" enctype="multipart/form-data" method="post">
                <div class="form-group">
                    <label>Dentistry Name</label>
                    <input type="hidden" id="id" name="id">
                    <input type="text" name="General_dentistry_name" id="General_dentistry" required>
                </div>
                <div class="form-group">
                    <label>Images</label>
                    <input type="file" name="image" id="image_dentistry" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea id="description_dentistry" name="description" rows="4" cols="50" required></textarea>
                    <script type="text/javascript">
                        CKEDITOR.replace('description_dentistry', {
                            height: 200,
                            width : 900
                        });
                    </script>
                </div>
                <div class="form-group">
                    <input type="submit" value="Update" class="btn btn-primary">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                </div>
            </form>

        </div>
    </div>
</div>