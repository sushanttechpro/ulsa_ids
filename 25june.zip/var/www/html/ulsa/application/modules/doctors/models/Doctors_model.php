<?php    
class Doctors_model extends CI_Model
{
    public function __construct()
    {

        // Set orderable column fields
        $this->table = 'doctor';
        $this->column_order = array( 'image','name','doctor_description');
        // Set searchable column fields
        $this->column_search = array('name','doctor_description');
        // Set default order
        $this->order = array('name' => 'asc');
    }
 
    public function getRows_dentistry($postData){
        $this->_get_datatables_query_dentistry($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $query = $this->db->get();
        return $query->result();
    }
    
    
    public function countAll_dentistry(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered_dentistry($postData){
        $this->_get_datatables_query_dentistry($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    
    private function _get_datatables_query_dentistry($postData){
         
        $this->db->from($this->table);
 
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

   
    public function add_Doctor($picture)
    {
        $this->db->insert('doctor',$picture);
        return true;
        
    }

    public function edit_Doctor($id)
    {
        $this->db->where('id',$id);
        $q=$this->db->get('doctor');
        return $q->result();
    }

    public function update_Doctor($picture,$id)
    {
        



        $this->db->where('id',$id);
        $this->db->update('doctor',$picture);
        return true;
    }

    public function delete_Doctor($id)
    {
      

        $this->db->where('id',$id);
        $q=  $this->db->get('doctor')->result()[0];
        $p=$q->{'image'};
        unlink(FCPATH.'/'.$p);

        $this->db->where('id',$id);
        $this->db->delete('doctor');
        return true;

    }


   

}