<?php    
class Doctors extends CI_Controller
{
    public function __construct()
    {
        parent:: __construct();
        $this->load->model('Doctors_model');
        $this->load->helper('url');
        $this->load->library('session');
        
    }

    public function index()
    {
        

        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header',$data);
        $this->load->view('index',$data);
        $this->load->view('footer',$data);
        
    }

    public function fetch_Doctors()
    {
        $data = $row = array();
        $rows = $this->Doctors_model->getRows_dentistry($_POST);
        foreach ($rows as $users) {
            $data[] = array(  '<img src="'.$users->image.' " width="100" height="100"> ', 
           $users->name,$users->doctor_description,
            // ' <a href="' . $this->config->item("base_url") . 'users/edit_User?id=' . $users->id . ' " class="btn btn-primary edit"> <i class="fa fa-pencil"></i>Edit</a>',
 
         '<button type="button" name="update" id="'.$users->id.'" class="btn btn-success edit_doctor ">Edit</button>',
        '<button type="button" name="delete" id="'.$users->id.'" class="btn  text-white btn-raised bg-red btn-sm waves-effect  delete_doctor"><span class="material-icons">
        delete
        </span>Delete</button>',
  
         );
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Doctors_model->countAll_dentistry($_POST),
            "recordsFiltered" => $this->Doctors_model->countFiltered_dentistry($_POST),
            "data" => $data,
        );
        echo json_encode($output);
    }

   

    public function add_Doctor()
    {  
        
        $config['upload_path'] = './assets/images/doctor/';  
        $config['allowed_types'] = 'jpg|jpeg|png|gif';  
        $this->load->library('upload', $config);  
        if(!$this->upload->do_upload('image'))  
        {  
            echo $this->upload->display_errors();  
        }  
        else  
        {  
            $data = $this->upload->data();  

            $picture = array(
            'image'=>'assets/images/doctor/'.$data['file_name'],'name'=>$_POST['name'],
            'doctor_description'=>$_POST['Ck_editor_value']       
                );
        $this->Doctors_model->add_Doctor($picture);
        echo true;
        } 
    }

    public function edit_Doctor()
    {
       
        $output = array();  
        $data = $this->Doctors_model->edit_Doctor($_POST["id"]);  
        foreach($data as $row)  
        {
             $output['id']=$row->id;
            //  $output['image'] = $row->image;  
             $output['name'] = $row->name;  
            //  $output['doctor_description'] = $row->doctor_description;  

        }  
        echo json_encode($output);

    }

    public function update_Doctor()
    {

        $id=$_POST['id'];

        $this->db->where('id',$id);
        $q=  $this->db->get('doctor')->result()[0];
        $p=$q->{'image'};
        unlink(FCPATH.'/'.$p);
       
        $config['upload_path'] = './assets/images/doctor/';  
        $config['allowed_types'] = 'jpg|jpeg|png|gif';  
        $this->load->library('upload', $config);  
        if(!$this->upload->do_upload('image'))  
        {  
            echo $this->upload->display_errors();  
        }  
        else  
        {  
            $data = $this->upload->data();  

            $picture = array(
            'image'=>'assets/images/doctor/'.$data['file_name'],'name'=>$_POST['name'],
            'doctor_description'=>$_POST['Ck_editor_value']         
                );
        $this->Doctors_model->update_Doctor($picture,$id);
        echo true;

            
        }
        
    }
    public function delete_Doctor()
    {
        $id=$_POST['id'];
        $this->Doctors_model->delete_Doctor($id);
        echo true;

    }

    


   
     
  


}






?>