<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <!-- <h2>Payments</h2> -->
            <!-- <small class="text-muted">Welcome to Swift application</small> -->
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>Braces</h2>
                        <!-- <button type="button" class="btn btn-default waves-effect m-r-20" data-toggle="modal" data-target="#defaultModal">Add Member</button> -->

                       
                    </div>
                    <div class="body table-responsive">
                        <table class="table table-bordered table-striped table-hover js-basic-example dataTable" id="braces_table">
                            <thead>
                                <tr>
                                    <th> Name</th>
                                    <th>Link</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                       
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



    
</section>
<div class="color-bg"></div>