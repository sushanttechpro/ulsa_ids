<?php    
class Braces extends CI_Controller
{
    public function __construct()
    {
        parent:: __construct();
        $this->load->model('Braces_model');
        $this->load->helper('url');
        $this->load->library('session');
        
    }

    public function index()
    {
        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header',$data);
        $this->load->view('index',$data);
        $this->load->view('footer',$data);


        
    }

    public function fetch_Braces()
    {
        $data = $row = array();
        $rows = $this->Braces_model->getRows_dentistry($_POST);
        foreach ($rows as $users) {
            $data[] = array(  $users->Braces_post_op,$users->link,
           
            // ' <a href="' . $this->config->item("base_url") . 'users/edit_User?id=' . $users->id . ' " class="btn btn-primary edit"> <i class="fa fa-pencil"></i>Edit</a>',
 
         '<button type="button" name="update" id="'.$users->id.'" class="btn btn-success  ">Edit</button>',
        '<button type="button" name="delete" id="'.$users->id.'" class="btn  text-white btn-raised bg-red btn-sm waves-effect  "><span class="material-icons">
        delete
        </span>Delete</button>',
  
         );
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Braces_model->countAll_dentistry($_POST),
            "recordsFiltered" => $this->Braces_model->countFiltered_dentistry($_POST),
            "data" => $data,
        );
        echo json_encode($output);
    }
}