<?php    
class Auth_model extends CI_Model
{
    public function __construct()
    {
        parent:: __construct();
     
        
    }
   

    public function check_user_id($email)
    {
        $sql = "SELECT count(*) as count From users Where email = '$email'";
        $select = $this->db->query($sql);
        echo $select->result_array()[0]['count'];
       
    }

    public function select_email_login($email_address, $password)
    {
        $this->db->where('email', $email_address);
        $this->db->where('password', $password);
        $result = $this->db->get('users')->result();
        if ($result) {

            $session_data = array(
                'id' => $result[0]->id,
                'name' => $result[0]->name,
                'email' => $result[0]->email,
                'usertype'=>$result[0]->usertype,
            
                 );
            $this->session->set_userdata($session_data);
            echo 1;
        } else {
            echo 0;
        }
    }


   
  
}






?>