<?php    
class Auth extends CI_Controller
{
    public function __construct()
    {
        parent:: __construct();
        $this->load->model('Auth_model');
        $this->load->helper('url');
        $this->load->library('session');
		// $this->load->helper('cookie');
     
        
    }

    public function index()
    {
        if(!$this->session->userdata('id'))
        {
            $data['base_url'] = $this->config->item("base_url");
            $this->load->view('login',$data);
        }else{
            redirect('dashboard');
        }
        
        
        
    }


    public function check_email_login()
	{
        // print_r($_POST);die;
		$email = $_POST['email_address'];
		// $pass = $_POST['password'];
		$password = base64_encode($_POST['password']);
		// if ($_POST['remember'] == "true") {
		// 	set_cookie('user', $email, 60);
		// 	set_cookie('pass', $pass, 60);
		// }
		$select_user = $this->Auth_model->select_email_login($email, $password);
	}
	public function check_user_id()
	{
		$email = $_POST['email_address'];
		$select_user = $this->Auth_model->check_user_id($email);
	}

    public function forgot()
    {
        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('forgot',$data);

    }

   
  
    public function logout()
    {
        $session_data = array(
            'id',
            'name',
            'email',
            'usertype'
        
             );
             $this->session->unset_userdata($session_data);
             $this->session->sess_destroy();
        redirect('auth');

    }
  

   
    
   

    
        

}






?>