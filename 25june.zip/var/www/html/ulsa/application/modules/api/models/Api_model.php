<?php

class Api_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function signup($add)
    {
        $add['password'] = base64_encode($add['password']);
        $this->db->where('email', $add['email']);

        $result = $this->db->get('users');

        if ($result->result()) {
            $json = array(
                'status_code' => 6,
                'st' => 'error',
                'txt' => 'email already exist',
            );
            http_response_code(400);

            return $json;
        } else {
            $add['usertype'] = 3;
            $dataArray = array('name' => $add['name'], 'email' => $add['email'], 'password' => $add['password'], 'token' => $add['token'], 'usertype' => 2,'push_notification_state' => $add['push_notification_state'],'desired_clinic' => $add['desired_clinic'],'special_notification' => $add['special_notification']);
            $this->db->insert('users', $dataArray);
            $client_id = $this->db->insert_id();
            $this->db->select('users.*');
            $this->db->from('users');
            $this->db->where('users.id', $client_id);
            $returnArray = $this->db->get()->result()[0];

            $json = array(
                'status_code' => 200,
                'status' => 'success',
                'data' => $returnArray,

            );
            return $json;

        }
    }
    /////////////////////////////////// mail Sent/////////////////////////////////////
    public function sendMail($to, $subject, $message)
    {
        $this->load->library('email');
        $config = array(
            'protocol' => 'smtp',
            'smtp_host' => 'smtp.sendgrid.net',
            'smtp_user' => 'amankumar11111',
            'smtp_pass' => 'aman11111',
            'smtp_port' => 587,
            'mailtype' => 'html',
            'charset' => 'utf-8',
            'crlf' => "\r\n",
            'newline' => "\r\n",
        );
        $this->email->initialize($config);
        $this->email->from('tiwariaman635@gmail.com', 'Vida');
        $this->email->to($to);
        $this->email->subject($subject);
        $this->email->message($message);
        $this->email->send();
    }
    /////////////////////////////////// mail Sent/////////////////////////////////////

    public function login($log)
    {
        $this->db->where('email', $log['email']);
        $data = $this->db->get('users');
        if (!$data->result()) {
            $json = array(
                'status_code' => 209,
                'status' => 'error',
                'txt' => 'email not exist',

            );
            http_response_code(400);

        } else {

            $this->db->select('users.*');
            $this->db->from('users');
            $this->db->where('users.usertype', 2);
            $this->db->where('users.password', base64_encode($log['password']));
            $this->db->where('users.email', $log['email']);
            $data = $this->db->get()->result();

            if ($data == null) {
                $json = array(
                    'status_code' => 207,
                    'status' => 'error',
                    'txt' => 'invalid credentials',

                );
                http_response_code(400);

            } else {
                if ($data) {
                    $json = array(
                        'status_code' => 200,
                        'status' => 'success',
                        'data' => $data[0],

                    );
                }
            }
        }return $json;
    }
/********************* store appointment ****************************************/

public function createAppointment($postData, $user_id)
{
    $date = date_create($postData['appointment_date']);

     $create = $this->db->insert('appointment', array('user_id' => $user_id, 'appointment_type' => $postData['appointment_type'],  'appointment_date' => $postData['appointment_date'],'appointment_state' => 'Pending', 'Prefer_time' => $postData['Prefer_time']));
    $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'creation success');


    return $json;

}


/********************* family member ****************************************/
 
function getName($n) { 
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
    $randomString = ''; 
  
    for ($i = 0; $i < $n; $i++) { 
        $index = rand(0, strlen($characters) - 1); 
        $randomString .= $characters[$index]; 
    } 
  
    return $randomString; 
}
public function family_member($postData, $user_id)
{
    $member_uniqId=$this->getName(8);
  $create = $this->db->insert('family_member', array('user_id' => $user_id,'Firstname' => $postData['Firstname'],'Lastname' => $postData['Lastname'],'phone_number' => $postData['phone_number'],'member_uniqId' => $member_uniqId ));
    $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'creation success');

    return $json;
}
/////////////////////  Update_family_member ///////////////////
public function Update_family_member($postData, $user_id)
{  
    $this->db->where('user_id', $user_id);
    $this->db->where('member_uniqId',$postData['member_uniqId']);
   $this->db->update('family_member', array('Firstname' => $postData['Firstname'],'Lastname' => $postData['Lastname'],'phone_number' => $postData['phone_number'] ));
    $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'Updation success');

    return $json;
}
/////////////////////  Update_family_member ///////////////////



    public function change_password($data)
    {
        $updatepass = array('password' => base64_encode($data['password']));
        $this->db->where('id', $data['user_id']);
        $updatep = $this->db->update('user', $updatepass);
        if ($updatep) {
            return true;
        } else {
            return false;
        }
    }

    public function getAnimals($user_id)
    {

        $animalData = $this->db->query("SELECT a1.*, a3.species_name, a4.breed_name, (SELECT max(date_of_appointment) dateee FROM appointment_table where animal_id=a1.id) date_of_appointment FROM animal as a1 LEFT JOIN species as a3 ON a3.id=a1.species_id LEFT JOIN breeds as a4 ON a4.id=a1.breed_id WHERE a1.client_id = " . $user_id, false)->result();
        return $animalData;
    }

    public function getclinic()
    {
        $this->db->where('usertype', 2);
        $this->db->where('status', 1);
        $clinic = $this->db->get('user')->result();
        return $clinic;
    }

/********************* update profile ****************************************/

    public function updateProfile($postData, $user_id)
    {

        $imgName = $this->db->query('SELECT image FROM user WHERE id=' . $user_id)->row()->image;
        $valid_extensions = array('jpeg', 'jpg', 'png');

        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {

            $img = $_FILES['image']['name'];
            $tmp = $_FILES['image']['tmp_name'];
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            if (in_array($ext, $valid_extensions)) {

                $final_image = str_replace(" ", "_", rand(1000, 1000000) . $img);

                $path = "assets/images/face/" . strtolower($final_image);
                if (move_uploaded_file($tmp, $path)) {

                    $imgName = $path;

                }

            } else {
                $json = array('status_code' => 99, 'status' => 'error', 'txt' => 'Image Invalid formate');
                http_response_code(400);

                return $json;
            }
        }

        if (isset($postData['password']) && !empty($postData['password'])) {
            $password = base64_encode($postData['password']);
            $dataArray = array('name' => $postData['name'], 'password' => $password, 'image' => $imgName);

        } else {
            $dataArray = array('name' => $postData['name'], 'image' => $imgName);

        }

        $this->db->where('id', $user_id);
        $rest = $this->db->update('user', $dataArray);

        if ($rest) {
            $clientInfo = array('address' => $postData['address'], 'city' => $postData['city'], 'post_code' => $postData['post_code'], 'tel_no1' => $postData['tel_no1'], 'tel_no2' => $postData['tel_no2'], 'clinic_id' => $postData['clinic_id']);

            $this->db->where('client_id', $user_id);
            $resupdate = $this->db->update('client_information', $clientInfo);
        }
        $this->db->select('user.* ,client_information.client_number,client_information.tax_number,client_information.address,client_information.city,client_information.post_code,client_information.tel_no1,client_information.tel_no2,client_information.clinic_id');
        $this->db->from('user');
        $this->db->join('client_information', 'user.id=client_information.client_id', 'left');
        $this->db->where('user.id', $user_id);
        $returnArray = $this->db->get()->result()[0];

        $json = array(
            'status_code' => 200,
            'status' => 'success',
            'data' => $returnArray,
        );
        return $json;

    }

/********************* get breed and species ****************************************/

    public function getBreedAndSpecies()
    {
        $getData = new stdClass();
        $this->db->select('id,breed_name,species_id');
        $getData->breeds = $this->db->get('breeds')->result();
        $this->db->select('id,species_name');
        $getData->species = $this->db->get('species')->result();
        return $getData;
    }

/********************* store animal ****************************************/

    public function createAnimal($postData, $user_id)
    {
        $imgName = "assets/images/animal/default.png";
        $valid_extensions = array('jpeg', 'jpg', 'png');

        if (isset($_FILES['animal_image']) && $_FILES['animal_image']['error'] == 0) {

            $img = $_FILES['animal_image']['name'];
            $tmp = $_FILES['animal_image']['tmp_name'];
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            if (in_array($ext, $valid_extensions)) {

                $final_image = str_replace(" ", "_", rand(1000, 1000000) . $img);

                $path = "assets/images/animal/" . strtolower($final_image);
                if (move_uploaded_file($tmp, $path)) {

                    $imgName = $path;
                  }

            } else {
                $json = array('status_code' => 99, 'status' => 'error', 'txt' => 'Image Invalid formate');
                http_response_code(400);

                return $json;
            }
        }
        $this->db->insert('animal', array('client_id' => $user_id, 'animal_image' => $imgName, 'animal_name' => $postData['animal_name'], 'species_id' => $postData['species_id'], 'breed_id' => $postData['breed_id'], 'date_of_birth' => $postData['date_of_birth'], 'electronic_number' => $postData['electronic_number']));
        $animal_id = $this->db->insert_id();
        $this->db->select('*');
        $this->db->from('animal');
        $this->db->where('animal.id', $animal_id);
        $returnArray = $this->db->get()->result()[0];
        $json = array('status_code' => 200, 'status' => 'success', 'data' => $returnArray, 'txt' => 'creation success');
        return $json;

    }

/********************* update animal ****************************************/

    public function updateAnimal($postData, $user_id, $animal_id)
    {

        $imgName = $this->db->query('SELECT animal_image FROM animal WHERE id=' . $animal_id)->row()->animal_image;
        $valid_extensions = array('jpeg', 'jpg', 'png');

        if (isset($_FILES['animal_image']) && $_FILES['animal_image']['error'] == 0) {

            $img = $_FILES['animal_image']['name'];
            $tmp = $_FILES['animal_image']['tmp_name'];
            $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
            if (in_array($ext, $valid_extensions)) {

                $final_image = str_replace(" ", "_", rand(1000, 1000000) . $img);

                $path = "assets/images/face/" . strtolower($final_image);
                if (move_uploaded_file($tmp, $path)) {
                    if (file_exists($imgName)) {
                        unlink($imgName);
                    }
                    $imgName = $path;

                }

            } else {
                $json = array('status_code' => 99, 'status' => 'error', 'txt' => 'Image Invalid formate');
                http_response_code(400);

                return $json;
            }
        }

        $this->db->where('id', $animal_id);
        $this->db->where('client_id', $user_id);
        $update = $this->db->update('animal', array('animal_image' => $imgName, 'animal_name' => $postData['animal_name'], 'species_id' => $postData['species_id'], 'breed_id' => $postData['breed_id'], 'date_of_birth' => $postData['date_of_birth'], 'electronic_number' => $postData['electronic_number']));

        if ($update) {
            $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'updation success');

            return $json;
        } else {
            $json = array('status' => 'error', 'txt' => 'updation failed');
            http_response_code(400);

            return $json;
        }
    }

/********************* delete animal ****************************************/

    public function deleteAnimal($user_id, $animal_id)
    {

        $imgName = $this->db->query('SELECT animal_image FROM animal WHERE id=' . $animal_id)->row()->animal_image;
        if (file_exists($imgName)) {
            unlink($imgName);
        }

        $this->db->where('client_id', $user_id);
        $this->db->where('id', $animal_id);
        $this->db->delete('animal');
        $this->db->where('animal_id', $animal_id);
        $del = $this->db->delete('appointment_table');

        $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'deletion success');
        return $json;

    }

/********************* create appointment types ****************************************/

    public function getAppointmentTypes()
    {
        $this->db->select('id,appointment_type');
        $getData = $this->db->get('appointment_type')->result();
        return $getData;
    }

/********************* create appointment types ****************************************/

    public function getClinics()
    {
        $this->db->where('usertype', 2);
        $this->db->select('id,name');
        $getData = $this->db->get('user')->result();
        return $getData;
    }



/********************* get appointments ****************************************/

    public function getAppointments($user_id)
    {
        $appointmentData = new stdClass();

        $this->db->select('animal.animal_name,animal.animal_image,specialties.specialty_name as appointment_type,user.name as clinic_name,appointment_table.status,appointment_table.date_of_appointment,appointment_table.time,appointment_table.appointment_state');
        $this->db->from('appointment_table');
        $this->db->join('animal', 'appointment_table.animal_id=animal.id');
        $this->db->join('specialties', 'appointment_table.appointment_id=specialties.id');
        $this->db->join('user', 'appointment_table.clinic_id=user.id');
        $this->db->where("appointment_table.status=",1);
        $this->db->where("appointment_table.client_id", $user_id);
        $this->db->where("appointment_table.date_of_appointment >=", date('Y-m-d'));
        $appointmentData->upcomming = $this->db->get()->result();

        $this->db->select('animal.animal_name,animal.animal_image,specialties.specialty_name as appointment_type,user.name as clinic_name,appointment_table.date_of_appointment,appointment_table.time,appointment_table.appointment_state');
        $this->db->from('appointment_table');
        $this->db->join('animal', 'appointment_table.animal_id=animal.id');
        $this->db->join('specialties', 'appointment_table.appointment_id=specialties.id');
        $this->db->join('user', 'appointment_table.clinic_id=user.id');
        $this->db->where("appointment_table.client_id", $user_id);
        $this->db->where("appointment_table.date_of_appointment <", date('Y-m-d'));
        $appointmentData->past = $this->db->get()->result();
        $last = $this->db->last_query();
        return $appointmentData;

    }

    public function send_message($postData, $user_id)
    {

        $array = array(
            'from_user_id' => $user_id,
            'created_date' => date('d-m-Y H:i'),
            'message' => $postData['message'],
            'client_id' => $user_id,
        );
        $this->db->insert('message_table', $array);
        $this->db->where('client_id', $user_id);
        $this->db->delete('message_flag');

        $this->db->where('usertype !=', 3);
        $usersData = $this->db->get('user')->result();
        $data = array();
        foreach ($usersData as $id_of_user) {
            $data[] = array("user_id" => $id_of_user->id, "client_id" => $user_id);
        }

        $this->db->insert_batch('message_flag', $data);

        $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'message created');
        return $json;
    }

/********************* get appointments ****************************************/

    public function getCampaigns()
    {

        $this->db->where('status', 1);
        $this->db->select('id,title,image,link');
        return $this->db->get('campaigns')->result();
    }

/********************* get Documents ****************************************/

    public function getDocuments($user_id)
    {

        $this->db->select('id,title,document_path,document_name,date');
        $this->db->where('client_id', $user_id);
        return $this->db->get('document_table')->result();
    }

/********************* get communications ****************************************/

    public function getCommunications()
    {
        $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'need to develop');
        return $json;
    }

/********************* get messages ****************************************/

    public function getMessages($user_id)
    {
        $this->db->select("message_table.*, user.image,user.name");
        $this->db->join("user", "user.id=message_table.from_user_id", "left");
        return $this->db->get_where('message_table', array('client_id' => $user_id))->result();
    }

/****************************** set_prefered_clinic ****************************************/

    public function set_prefered_clinic($clinic_id, $user_id)
    {

        $this->db->where('client_id', $user_id);
        $this->db->update('client_information', array('clinic_id' => $clinic_id['clinic_id']));
        $json = array('status_code' => 200, 'status' => 'success', 'txt' => 'clinic set');
        return $json;
    }

    public function addPlayerId($playerId, $userId)
    {
        $this->db->delete('player', array('player_id' => $playerId));
        $this->db->insert('player', array('player_id' => $playerId, 'customer_id' => $userId));
    }

    public function deletePlayerId($user_id)
    {
        $this->db->delete('player', array('customer_id' => $user_id));
    }

    public function get_communication($clinic_id, $user_id)
    {
        if (isset($clinic_id['clinic_id'])) {
            $this->db->where("clinic_id", $clinic_id['clinic_id']);
            $this->db->or_where("clinic_id", 0);
        }
        else{
            $this->db->where("clinic_id", 0);
        }
        $communicationData = $this->db->get('communication')->result();
        return $communicationData;
    }

    public function change_notification($user_id)
    {
        $this->db->where('client_id', $user_id);
        return $this->db->update('notification_table', array('status' => 1));
    }
    public function notification_count($user_id)
    {
        return $this->db->get_where('notification_table', array('client_id' => $user_id, 'status' => 0))->num_rows();

    }
    public function delete_User($id)
    {
        $this->db->trans_start();
        $this->db->query("DELETE FROM client_information WHERE client_id='$id'");
        $this->db->query("DELETE FROM animal WHERE client_id='$id'");
        $this->db->query("DELETE FROM appointment_table WHERE client_id='$id'");
        $this->db->query("DELETE FROM discount_table WHERE client_id='$id'");
        $this->db->query("DELETE FROM document_table WHERE client_id='$id'");
        $this->db->query("DELETE FROM invoice_table WHERE client_id='$id'");
        $this->db->query("DELETE FROM message_flag WHERE client_id='$id'");
        $this->db->query("DELETE FROM message_table WHERE client_id='$id'");
        $this->db->query("DELETE FROM user_credit_table WHERE client_id='$id'");
        $this->db->query("DELETE FROM player WHERE customer_id='$id'");
        $this->db->query("DELETE FROM user WHERE id='$id'");
        $this->db->trans_complete();
        return 1;
    }

    public function get_user_credit($client_id)
    {
        $credit = $this->db->query("select (IFNULL((SELECT SUM(user_credit_table.credit_of_user) FROM user_credit_table WHERE client_id = " . $client_id . "),0) - IFNULL((SELECT SUM(discount_table.discount) FROM discount_table WHERE client_id = " . $client_id . "),0)) credit")->result();
        return $credit;
    }

    public function get_user_discount($client_id)
    {
        return $this->db->get_where('discount_table', array('client_id' => $client_id))->result();
    }

}
