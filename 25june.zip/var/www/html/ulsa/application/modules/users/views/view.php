<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <!-- <h2>Payments</h2> -->
            <!-- <small class="text-muted">Welcome to Swift application</small> -->
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>Family Member</h2>
                        <button type="button" class="btn btn-default waves-effect m-r-20" data-toggle="modal" data-target="#defaultModal">Add Member</button>

                       
                    </div>
                    <div class="body table-responsive">
                        <table class="table table-bordered table-striped table-hover js-basic-example dataTable" data-id="<?=$id?>" id="members_table">
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Phone Number</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                        
                       
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



    
</section>
<div class="color-bg"></div>


<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="defaultModalLabel">Add memeber</h4>
            </div>
    
                <form method="post" id="add_member" >
                    <div class="form-group">
                        <input type="hidden"  value="<?php echo $id ?>" id="id" name="id">
                    <input type="text" name="Firstname" id=" Firstname"required placeholder="First Name" required >
                    </div>
                    <div class="form-group">
                    <input type="text" name="Lastname" id="Lastname" required placeholder="Last Name" required >
                    </div>
                    <div class="form-group">
                    <input type="text" name="phone_number" id="phone_number"required placeholder="Mobile Number" required >

                    </div>

                    <input type="submit">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>

            
            </form>
        </div>
    </div>
</div>