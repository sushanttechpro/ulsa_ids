<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Users extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form', 'url');
		$this->load->model('Users_model');	
    }

    public function index()
    {
        

        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header',$data);
        $this->load->view('index',$data);
        $this->load->view('footer',$data);
        
    }

    public function fetch_Users()
    {
        $data = $row = array();
        $rows = $this->Users_model->getRows_users($_POST);
        foreach ($rows as $users) {
            $data[] = array($users->name, 
           $users->email,$users->desired_clinic,
            // ' <a href="' . $this->config->item("base_url") . 'users/edit_User?id=' . $users->id . ' " class="btn btn-primary edit"> <i class="fa fa-pencil"></i>Edit</a>',
            $users->status=="0"?'<label class="switch">
            <input type="checkbox" id="userstatus" data-user_toggle="' . $users->id . '"  >
            <span class="slider round"></span>
          </label>':'<label class="switch">
          <input type="checkbox" id="userstatus" data-user_toggle="' . $users->id . '" checked >
          <span class="slider round"></span>
        </label>',
        //  '<button type="button" name="update" id="'.$users->id.'" class="btn btn-success edituser">View</button>',
         ' <a href="' . $this->config->item("base_url") . 'users/view_User?id=' . $users->id . ' " class="btn text-white btn-raised bg-info btn-sm waves-effect"><span class="material-icons">
         remove_red_eye </span> View</a>',

        '<button type="button" name="delete" id="'.$users->id.'" class="btn  text-white btn-raised bg-red btn-sm waves-effect  deleteuser"><span class="material-icons">
        delete
        </span>Delete</button>',

           
          
           
         );
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Users_model->countAll_users($_POST),
            "recordsFiltered" => $this->Users_model->countFiltered_users($_POST),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function add_User()
    {

        $data['clinic']=$this->Users_model->get_desired_clinic();
        // print_r($data);
        $data['base_url'] = $this->config->item("base_url");
        $this->load->view('header',$data);
        $this->load->view('adduser',$data);
        $this->load->view('footer',$data);

    }

    public function checkEmail()
    {
   
       $email = $_POST['email'];
		$select_user = $this->Users_model->checkEmail($email);
  
    }

    public function insertUser()
    { 
        $Token=substr(md5(uniqid(mt_rand(), true)), 0, 15);
        // if($_POST['push_notification_state']||$_POST['special_notification']=="on")
        // {
            $data=array('name'=>$_POST['name'],'email'=>$_POST['email'],'usertype'=>2,'token'=>$Token,
            'push_notification_state'=>(isset($_POST['push_notification_state'])=="on") ? 1 : 0,'special_notification'=>(isset($_POST['special_notification'])=="on") ? 1 : 0,
            'desired_clinic'=>$_POST['desired_clinic'],'password'=>base64_encode($_POST['password'])
            );
            $this->Users_model->insertUser($data);
            echo true;

        // }else if( $_POST['push_notification_state']||$_POST['special_notification']==" "){
        //     $data=array('name'=>$_POST['name'],'email'=>$_POST['email'],'usertype'=>2,'token'=>$Token,
        //     'push_notification_state'=>0,'special_notification'=>0,
        //     'desired_clinic'=>$_POST['desired_clinic'],'password'=>base64_encode($_POST['password'])
        //     );
      


        
        // $this->Users_model->insertUser($data);


    }

   

    

    public function edit_User()
    {
        $output = array();  
           $data = $this->Users_model->edit_User($_POST["id"]);  
           foreach($data as $row)  
           {
                $output['id']=$row->id;
                $output['firstname'] = $row->firstname;  
                $output['lastname'] = $row->lastname;
                $output['email']=$row->email;
                $output['mobile']=$row->mobile;

           }  
           echo json_encode($output);
    }

    public function updateUsers()
    {
        $id=$_POST['id'];
        $data=array('firstname'=>$_POST['firstname'],'lastname'=>$_POST['lastname'],
        'email'=>$_POST['email'],'mobile'=>$_POST['mobile']);
        $this->Users_model->updateUsers($id,$data);
        echo true;
    }

    public function deleteUser()
    {
        $id=$_POST['id'];
        $this->Users_model->deleteUser($id);
         echo true;
    }

    public function change_user_status()
    {
        if($_POST['prop'] == "false")
        {
            $this->db->where('id',$_POST['id']);
            $this->db->update('users',array('status'=>0));
        }
        else
        {
            $this->db->where('id',$_POST['id']);
            $this->db->update('users',array('status'=>1));
        }
    }

    public function view_user()
    {
        // $id=$_GET['id'];
       
        $data['base_url'] = $this->config->item("base_url");
        $data['id']=$_GET['id'];
        $this->load->view('header',$data);
        $this->load->view('view',$data);
        $this->load->view('footer',$data);
    }


    public function fetch_member()
    {
    
        $data = $row = array();
        $rows = $this->Users_model->getRows_campaign($_POST);
        // $i=1;
        foreach ($rows as $all_campaign) {
            $data[] = array($all_campaign->Firstname,$all_campaign->Lastname,
            $all_campaign->phone_number,
            '<button type="button" name="update" id="'.$all_campaign->id.'" class="btn btn-success  ">Edit</button>',

            '<button type="button" name="delete" id="'.$all_campaign->id.'" class="btn  text-white btn-raised bg-red btn-sm waves-effect  "><span class="material-icons">
            delete
            </span>Delete</button>',
       
        
     
        );
            
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Users_model->countAll_campaign($_POST),
            "recordsFiltered" => $this->Users_model->countFiltered_campaign($_POST),
            "data" => $data,
        );
        echo json_encode($output);

    }

    

    function getName($n) { 
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
        $randomString = ''; 
      
        for ($i = 0; $i < $n; $i++) { 
            $index = rand(0, strlen($characters) - 1); 
            $randomString .= $characters[$index]; 
        } 
      
        return $randomString; 
    }

    public function insertMember()
    {
        $member_uniqId=$this->getName(8); 
        $data=array('Firstname'=>$_POST['Firstname'],'Lastname'=>$_POST['Lastname'],'phone_number'=>$_POST['phone_number'],'member_uniqid'=>$member_uniqId,'user_id'=>$_POST['id']);

        $this->Users_model->insertMember($data);
        echo true;

    }

   
}