<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Users_model extends MY_Model
{
    public function __construct()
    {

        // Set orderable column fields
        $this->table = 'users';
        $this->column_order = array( 'name','email','desired_clinic','status');
        // Set searchable column fields
        $this->column_search = array('name','email','desired_clinic','status');
        // Set default order
        $this->order = array('name' => 'asc');
    }
 
    public function getRows_users($postData){
        $this->_get_datatables_query_users($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $this->db->like('usertype','2');
        $query = $this->db->get();
        return $query->result();
    }
    
    
    public function countAll_users(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered_users($postData){
        $this->_get_datatables_query_users($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    
    private function _get_datatables_query_users($postData){
         
        $this->db->from($this->table);
 
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }
                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    public function edit_User($id)
    {
        $this->db->where('id',$id);
        $q=$this->db->get('users');
        return $q->result(); 
    }

    public function updateUsers($id,$data)
    {
        $this->db->where('id',$id);
        $this->db->update('users',$data);
    }

    public function deleteUser($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('users');
    }

    public function get_desired_clinic()
    {
       $q= $this->db->get('desired_clinic')->result();
        return $q;
    }

    public function insertUser($data)
    {
        $this->db->insert('users',$data);

    }

    public function checkEmail($email)
    {
        
        $sql = "SELECT count(*) as count From users Where email = '$email'";
        $select = $this->db->query($sql);
        echo $select->result_array()[0]['count'];


    }

 

    ///datatable
 
    public function getRows_campaign($postData)
    {
        $this->_get_datatables_query_campaign($postData);
        if ($postData['length'] != -1) {
        $this->db->limit($postData['length'], $postData['start']);
         }
         $id=$_POST['id'];
         $this->db->where('user_id',$id);
        $query = $this->db->get('family_member')->result();
        return $query;
    }
    
    public function countAll_campaign($postData)
    {
        $this->_get_datatables_query_campaign($postData);
        return $this->db->count_all_results();
    }

    public function countFiltered_campaign($postData)
    {
        $this->_get_datatables_query_campaign($postData);
        $id=$_POST['id'];
        $this->db->where('user_id',$id);
        $query = $this->db->get('family_member');
        return $query->num_rows();
    }
    
    public function _get_datatables_query_campaign($postData)
    {
        $id=$_POST['id'];
        $this->db->where('user_id',$id);
        $this->db->get('family_member');
    }


    public function insertMember($data)
    {
        $this->db->insert('family_member',$data);
    }





}