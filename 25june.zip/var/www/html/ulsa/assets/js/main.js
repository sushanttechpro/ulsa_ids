var base_jsurl = "http://142.93.211.14/ulsa/";
var url = $(location).attr('href');
var parts = url.split("/");
var dashPart = parts[4].replace(/#/, "");
var last_part = parts[parts.length - 1];

$(document).ready(function() {
    "use strict";

    // ______________ PAGE LOADING
    $(window).on("load", function(e) {
        $("#global-loader").fadeOut("slow");
    })

    // ______________ BACK TO TOP BUTTON

    $(window).on("scroll", function(e) {
        if ($(this).scrollTop() > 300) {
            $('#back-to-top').fadeIn('slow');
        } else {
            $('#back-to-top').fadeOut('slow');
        }
    });

    $("#back-to-top").on("click", function(e) {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    $(".readonly").keydown(function(e) {
        e.preventDefault();
    });



    ////*****************////
    //// WHITE SPACE CHECK ////
    $("input").on("keypress", function(e) {
        if (e.which === 32 && !this.value.length)
            e.preventDefault();
    });

    $("textarea").on("keypress", function(e) {
        if (e.which === 32 && !this.value.length)
            e.preventDefault();
    });

    ////*****************////
    //// IS NUMBER CHECK ////
    $("body").on("keypress", ".telephone, .activationSet", function(event) {
        return isNumber(event, this)

    })

    ////Prevent Number////
    $(".preventNumber").on('input', function(event) {
        this.value = this.value.replace(/[^a-z\s]/gi, '');
    });
    ////Prevent Letters////
    $(".preventAlpha").on('input', function(event) {
        this.value = this.value.replace(/[^0-9]/gi, '');


    });

    function isNumber(evt, element) {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if ((charCode == 32 || $(element).val().indexOf(' ') == -1) && (charCode != 43 || $(element).val().indexOf('+') != -1) && (charCode < 48 || charCode > 57) && charCode !== 8)
            return false;
        return true;
    }

    // http://localhost/survey





    ////******************////
    //// USER LOGIN CHECK ////
    $("#email_address").on('blur', function() {
        var email_address = $("#email_address").val();
        $.ajax({
            url: base_jsurl + 'auth/check_user_id',
            type: 'POST',
            data: { email_address: email_address },
            success: function(data) {
                if (data == 0) {
                    $(".errLoginUser").text("Invalid Email");
                    $(".errLoginUser").css("display", "block");
                    return false;
                } else {
                    $(".errLoginUser").css("display", "none");
                    return true;
                }
            }
        })
    })



    ////***************////
    // LOGIN FORM//
    $("#login").on('submit', function(e) {
        e.preventDefault();

        var email_address = $("#email_address").val();
        var password = $("#userPassword").val();
        // var remember = $('#rememberme').is(':checked');

        $(".errLoginUser").css("display", "none");
        $(".errLoginPass").css("display", "none");
        $.ajax({
            url: base_jsurl + 'auth/check_user_id',
            type: 'POST',
            data: { email_address: email_address },
            success: function(data) {
                if (data == 0) {
                    $(".errLoginUser").text("Invalid Email");
                    $(".errLoginUser").css("display", "block");
                    return false;
                } else {
                    $(".errLoginUser").css("display", "none");
                    $.ajax({
                        url: base_jsurl + 'auth/check_email_login',
                        type: 'POST',
                        data: { email_address: email_address, password: password },
                        success: function(data) {
                            if (data == 1) {
                                $(".errLoginUser").css("display", "none");
                                $(".errLoginPass").css("display", "none");
                                window.location.replace(base_jsurl + "dashboard")

                            } else {
                                $(".errLoginPass").text("Invalid Password");
                                $(".errLoginPass").css("display", "block");
                                return false;
                            }
                        }
                    })
                }
            }
        })
    })

    ////****************////
    //// RESET PASSWORD ////
    $("#resetPasswordForm").on('submit', function(e) {
        e.preventDefault();
        $(".errResetEmail").css("display", "none");
        $.ajax({
            url: base_jsurl + 'auth/reset_pass_link',
            type: 'POST',
            data: $("#resetPasswordForm").serialize(),
            success: function(data) {
                if (data == 1) {
                    swal({
                        title: "Um link para recuperar a sua password foi enviado para o seu email.",
                        type: "success",
                        confirmButtonText: "OK"
                    }, function() {
                        window.location.href = base_jsurl + "auth/login";
                    });
                } else if (data == 0) {
                    $(".errResetEmail").text("Email inválido.");
                    $(".errResetEmail").css("display", "block");
                    return false;
                }
            }
        })
    })

    $("#passwordForm").on('submit', function(e) {
        e.preventDefault();
        if ($("#password").val() != $("#confPassword").val()) {
            $(".errResetPassword").css("display", "block");
        } else {
            $(".errResetPassword").css("display", "none");
            var abc = $(this).find("button[type=submit]").attr("attrb");
            // var id = $("input[type=submit]").attr("attrb")
            $.ajax({
                url: base_jsurl + 'auth/reset_pass',
                type: 'POST',
                data: $("#passwordForm").serialize(),
                success: function(data) {
                    if (data == 1) {
                        if (abc == "web") {
                            swal({
                                title: "A password foi alterada com sucesso.",
                                type: "success",
                                confirmButtonText: "OK"
                            }, function() {
                                window.location.href = base_jsurl + "auth/login";
                            });
                        } else {
                            swal({
                                title: "A password foi alterada com sucesso.",
                                type: "success",
                                confirmButtonText: "OK"
                            }, function() {
                                window.location.href = base_jsurl + "auth/pass_change_msg";
                            });
                        }

                    }
                }
            })
        }
    })

    ////***************////
    // Users Table//
    $('#users_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'users/fetch_Users',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [4, 5],

            "orderable": false
        }]
    });


    // Delete User//
    $(document).on("click", '.deleteuser', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this patient?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'users/deleteUser',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "users")
                            }
                        }
                    })
                }
            });
    })

    //Users Satus Chane Toggle button//
    $('body').on('change', '#userstatus', function() {
        var id = $(this).attr("data-user_toggle");
        if ($(this).prop("checked") == true) {
            var prop = $(this).prop("checked")
        } else {
            var prop = $(this).prop("checked")
        }
        $.ajax({
            url: base_jsurl + 'users/change_user_status',
            type: 'POST',
            data: { prop: prop, id: id },
            success: function(data) {}
        })

    });


    ////***************////
    // Add Users//
    $('#add_user').submit(function(e) {
        e.preventDefault();
        var formName = $(this);

        $(".errEmail").css("display", "none");
        $.ajax({
            url: base_jsurl + 'users/checkEmail',
            type: 'post',
            datatype: 'json',
            data: $(this).serialize(),
            data: { email: $("#email").val() },
            success: function(data) {
                if (data == 1) {
                    $(".errEmail").text("Email already exist");
                    $(".errEmail").css("display", "block");
                    // window.location.replace(base_jsurl + "users")
                } else {
                    $(".errEmail").css("display", "none");
                    $.ajax({
                        url: base_jsurl + 'users/insertUser',
                        type: 'post',
                        datatype: 'json',
                        // data: $(this).serialize(),
                        data: formName.serialize(),
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "users")
                            }
                        }
                    });
                }
                // });

            }
        });
    });


    //     $.ajax({
    //         url: base_jsurl + 'users/insertUser',
    //         type: 'post',
    //         datatype: 'json',
    //         data: $(this).serialize(),
    //         success: function(data) {
    //             if (data == true) {
    //                 window.location.replace(base_jsurl + "users")
    //             }
    //         }
    //     });
    // });


    // $('body').on('change', '#push_notification', function() {
    //     // var id = $(this).attr("data-user_toggle");
    //     if ($(this).prop("checked") == true) {
    //         // var prop = $(this).prop("checked")
    //         return 1;
    //     } else {
    //         // var prop = $(this).prop("checked")
    //         return 0;
    //     }


    // });

    var switchStatus = 1;
    $("#push_notification").on('change', function() {
        if ($(this).is(':checked')) {
            return $(this).is(':checked');
            // alert(switchStatus); // To verify
            // return 1;
        } else {
            return $(this).is(':checked');
            // alert(switchStatus); // To verify
            // return 0;
        }
    });


    ////***************////
    // Dentistry_table Table//
    $('#dentistry_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'dentistry/fetch_Dentistry',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [3, 4],

            "orderable": false
        }]

    });

    // Delete Dentistry//
    $(document).on("click", '.delete_dentistry', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this dentistry?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'dentistry/delete_Dentistry',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "dentistry")
                            }
                        }
                    })
                }
            });
    })



    $('#add_Dentistry').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description'].getData();
        var form = $('#add_Dentistry')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);
        $.ajax({
            url: base_jsurl + 'dentistry/add_Dentistry',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    window.location.replace(base_jsurl + "dentistry")
                }
            }
        });
    });


    ////***************////
    //Edit Dentistry popup//
    $(document).on('click', '.edit_dentistry', function() {

        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'dentistry/edit_Dentistry',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editModal').modal('show');
                $('#id').val(id);
                // $('#image_dentistry').val(data.image);
                $('#General_dentistry').val(data.General_dentistry_name);
                $('#description_dentistry').val(data.description);

            }
        })
    });

    $('#edit_Dentistry').submit(function(e) {
        // console.log(CKEDITOR.instances['description_dentistry'].getData());
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description_dentistry'].getData();
        var form = $('#edit_Dentistry')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);
        $.ajax({
            url: base_jsurl + 'dentistry/update_Dentistry',
            type: 'post',
            datatype: 'json',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    window.location.replace(base_jsurl + "dentistry")
                }
            }
        });
    });

    ////***************////
    // Doctor_table //
    $('#doctors_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'doctors/fetch_Doctors',
            "type": "POST",
        },
        "columnDefs": [{
            "targets": [3, 4],

            "orderable": false
        }]

    });


    $('#add_Doctor').submit(function(e) {
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['description'].getData();
        var form = $('#add_Doctor')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'doctors/add_Doctor',
            type: 'post',
            datatype: 'json',
            // data: $(this).serialize(),
            data: formData,
            processData: false,
            contentType: false,
            cache: false,
            success: function(data) {
                if (data == true) {
                    window.location.replace(base_jsurl + "doctors")
                }
            }
        });
    });


    ////***************////
    //Edit Doctor popup//
    $(document).on('click', '.edit_doctor', function() {
        var id = $(this).attr("id");
        $.ajax({
            url: base_jsurl + 'doctors/edit_Doctor',
            method: "POST",
            data: { id: id },
            dataType: "json",
            success: function(data) {
                $('#editDoctor').modal('show');
                $('#id').val(id);
                // $('#image_dentistry').val(data.image);
                $('#doctor_name').val(data.name);
                // $('#doctor_description').val(data.doctor_description);

            }
        })
    });


    $('#edit_Doctor').submit(function(e) {

        // alert(Ck_editor_value);
        // var editor = CKEDITOR.editor.replace('doctor_description');
        e.preventDefault();
        var Ck_editor_value = CKEDITOR.instances['doctor_description'].getData();
        var form = $('#edit_Doctor')[0];
        var formData = new FormData(form);
        formData.append('Ck_editor_value', Ck_editor_value);

        $.ajax({
            url: base_jsurl + 'doctors/update_Doctor',
            type: 'post',
            // data: new FormData(this),
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                if (data == true) {
                    window.location.replace(base_jsurl + "doctors")
                }
            }
        });
    });

    // Delete Doctors//
    $(document).on("click", '.delete_doctor', function() {
        var id = $(this).attr("id");
        swal({
                title: "Alert",
                text: "Are you sure want to delete this doctor?",
                type: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            },
            function(inputValue) {
                if (inputValue === true) {
                    $.ajax({
                        url: base_jsurl + 'doctors/delete_Doctor',
                        type: 'POST',
                        data: { id: id },
                        success: function(data) {
                            if (data == true) {
                                window.location.replace(base_jsurl + "doctors")
                            }
                        }
                    })
                }
            });
    })


    // Users Table//
    $('#members_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": false,
        "info": false,
        "lengthChange": false,
        "ordering": false,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'users/fetch_member',
            "type": "POST",
            'data': { "id": $("#members_table").attr("data-id") }
        },
        // "columnDefs": [{
        //     "targets": [4, 5],

        //     "orderable": false
        // }]
    });

    ////***************////
    // Add Member   //
    $('#add_member').submit(function(e) {
        // alert("gdbjhdf");

        e.preventDefault();
        $.ajax({
            url: base_jsurl + 'users/insertMember',
            type: 'post',
            datatype: 'json',
            data: $(this).serialize(),
            success: function(data) {
                if (data == true) {
                    window.location.replace(base_jsurl + "users")
                }
            }
        });
    });


    // Doctor_table //
    $('#braces_table').DataTable({
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "ajax": {
            "url": base_jsurl + 'braces/fetch_Braces',
            "type": "POST",
        },
        // "columnDefs": [{
        //     "targets": [3, 4],

        //     "orderable": false
        // }]

    });





});